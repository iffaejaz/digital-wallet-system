# test registration output
import hashlib
from db import get_connection

def hash_pwd(pwd):
    return hashlib.sha256(pwd.encode('utf-8')).hexdigest()

def test_registration():
    conn = get_connection()
    cur = conn.cursor()
    
    email = "test.output@wallet.com"
    pw = hash_pwd("password123")
    
    try:
        # check if test user exists
        cur.execute("SELECT UserID FROM [User] WHERE Email=?", (email,))
        if cur.fetchone():
            cur.execute("DELETE FROM [User] WHERE Email=?", (email,))
            conn.commit()
            
        print("Testing INSERT with OUTPUT INSERTED.UserID...")
        cur.execute(
            "INSERT INTO [User] (FullName, Email, PhoneNumber, CNIC, PasswordHash) OUTPUT INSERTED.UserID VALUES (?,?,?,?,?)",
            ("Test User", email, "0300-9999999", "35201-9999999-9", pw)
        )
        new_uid = cur.fetchone()[0]
        print(f"Success! New UserID: {new_uid}")
        
        # cleanup
        cur.execute("DELETE FROM [User] WHERE UserID=?", (new_uid,))
        conn.commit()
        print("Test passed and cleaned up.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    test_registration()
