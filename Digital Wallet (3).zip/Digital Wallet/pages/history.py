# history page - all transactions

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from db import get_connection
from utils.auth import check_session
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — History", page_icon="📜", layout="wide")
check_session()
render_sidebar()

st.title("📜 Transaction History")
st.caption("Track all your wallet activity in one place")

# filters row
col_f1, col_f2, col_f3, col_f4 = st.columns(4)
with col_f1:
    start_date = st.date_input("From Date", value=datetime.now() - timedelta(days=365), key="h_from")
with col_f2:
    end_date = st.date_input("To Date", value=datetime.now(), key="h_to")
with col_f3:
    direction = st.selectbox("Type", ["All", "Sent", "Received"], key="h_dir")
with col_f4:
    search = st.text_input("Search Reference", placeholder="TXN-...", key="h_ref")

uid = int(st.session_state.get('user_id', 0))

with st.spinner("Loading transactions..."):
    try:
        conn = get_connection()
        cur = conn.cursor()

        # base query - transfers
        query = """
        select t.ReferenceNumber,
               case when w_send.UserID = ? then 'Sent' else 'Received' end as Direction,
               case when w_send.UserID = ? then u_recv.FullName else u_send.FullName end as OtherParty,
               t.Amount, t.TransactionDate, t.Status, t.Description
        from [Transaction] t
        join Wallet w_send on t.SenderWalletID = w_send.WalletID
        join Wallet w_recv on t.ReceiverWalletID = w_recv.WalletID
        join [User] u_send on w_send.UserID = u_send.UserID
        join [User] u_recv on w_recv.UserID = u_recv.UserID
        where (w_send.UserID = ? or w_recv.UserID = ?)
        """
        params = [uid, uid, uid, uid]

        # add date filter
        if start_date:
            query += " and cast(t.TransactionDate as date) >= ?"
            params.append(start_date)

        if end_date:
            query += " and cast(t.TransactionDate as date) <= ?"
            params.append(end_date)

        # add direction filter
        if direction != 'All':
            if direction == 'Sent':
                query += " and w_send.UserID = ?"
                params.append(uid)
            else:
                query += " and w_recv.UserID = ?"
                params.append(uid)

        # add search filter on reference number
        if search:
            query += " and t.ReferenceNumber like ?"
            params.append(f"%{search}%")

        query += " order by t.TransactionDate desc"
        cur.execute(query, params)
        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]
        conn.close()

        if rows:
            # build dataframe
            data = []
            for r in rows:
                rd = {}
                for i, col in enumerate(cols):
                    val = r[i]
                    if col == 'Amount':
                        val = f"PKR {val:,.2f}"
                    elif col == 'TransactionDate':
                        val = val.strftime('%d %b %Y, %I:%M %p')
                    elif val is None:
                        val = 'N/A'
                    rd[col] = val
                data.append(rd)

            df = pd.DataFrame(data)
            st.markdown(f"**{len(rows)} transaction(s) found**")
            st.dataframe(df, use_container_width=True, hide_index=True)

            # summary metrics
            st.divider()
            mc1, mc2, mc3 = st.columns(3)
            with mc1:
                st.metric("Total Transactions", len(rows))
            with mc2:
                total_amt = sum(r.Amount for r in rows)
                st.metric("Total Amount", f"PKR {total_amt:,.2f}")
            with mc3:
                avg_amt = total_amt / len(rows) if rows else 0
                st.metric("Average Amount", f"PKR {avg_amt:,.2f}")
        else:
            st.info("📭 No transactions found for the selected filters.")
    except Exception as e:
        st.error(f"Error: {e}")
