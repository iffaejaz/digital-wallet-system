# profile page - view and update info

import streamlit as st
from db import get_connection
from utils.auth import check_session
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — Profile", page_icon="👤", layout="wide")
check_session()
render_sidebar()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
html,body,[class*="st-"]{font-family:'Inter',sans-serif}
.ph{background:linear-gradient(135deg,#0d3b1e,#1A6B3C,#2E8B57);padding:30px;border-radius:18px;color:#fff;text-align:center;margin-bottom:25px;box-shadow:0 10px 35px rgba(26,107,60,.25)}
.ph h2{font-weight:800;margin-bottom:4px}.ph p{opacity:.8;font-size:14px}
.profile-card{background:#fff;border:1px solid #e8f5ee;border-radius:16px;padding:30px;box-shadow:0 4px 15px rgba(0,0,0,.04)}
</style>
<div class="ph"><h2>👤 My Profile</h2><p>View and update your account information</p></div>
""", unsafe_allow_html=True)

uid = int(st.session_state.get('user_id', 0))

# get user data
with st.spinner("Loading profile..."):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT FullName, Email, PhoneNumber, CNIC, Role, CreatedAt, IsActive "
            "FROM [User] WHERE UserID=?", (uid,))
        user = cur.fetchone()
        cur.execute("SELECT WalletNumber, Balance, Status, CreatedAt FROM Wallet WHERE UserID=?", (uid,))
        wallet = cur.fetchone()
        conn.close()
    except Exception as e:
        st.error(f"❌ Error: {e}")
        st.stop()

if not user:
    st.error("User not found.")
    st.stop()

col1, col2 = st.columns([1, 1], gap="large")

with col1:
    st.markdown("### 📋 Account Details")
    status_clr = '#1A6B3C' if user.IsActive else '#dc3545'
    status_txt = 'Active' if user.IsActive else 'Suspended'
    st.markdown(f'<div class="profile-card"><div style="text-align:center;margin-bottom:20px">'
        f'<div style="font-size:60px">👤</div>'
        f'<div style="font-size:22px;font-weight:700;color:#1A6B3C">{user.FullName}</div>'
        f'<div style="font-size:13px;color:#888">{user.Role} • Joined {user.CreatedAt.strftime("%B %Y")}</div></div><hr>'
        f'<div style="padding:10px 0">'
        f'<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0">'
        f'<span style="color:#888">📧 Email</span><span style="font-weight:600">{user.Email}</span></div>'
        f'<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0">'
        f'<span style="color:#888">📱 Phone</span><span style="font-weight:600">{user.PhoneNumber}</span></div>'
        f'<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0">'
        f'<span style="color:#888">🆔 CNIC</span><span style="font-weight:600">{user.CNIC}</span></div>'
        f'<div style="display:flex;justify-content:space-between;padding:8px 0">'
        f'<span style="color:#888">✅ Status</span>'
        f'<span style="font-weight:600;color:{status_clr}">{status_txt}</span></div>'
        f'</div></div>', unsafe_allow_html=True)

    if wallet:
        st.markdown(f'<div class="profile-card" style="margin-top:20px">'
            f'<div style="font-weight:700;font-size:16px;margin-bottom:12px">💰 Wallet Info</div>'
            f'<div style="display:flex;justify-content:space-between;padding:6px 0">'
            f'<span style="color:#888">Wallet Number</span><span style="font-weight:600;font-family:monospace">{wallet.WalletNumber}</span></div>'
            f'<div style="display:flex;justify-content:space-between;padding:6px 0">'
            f'<span style="color:#888">Balance</span><span style="font-weight:700;color:#1A6B3C">PKR {wallet.Balance:,.2f}</span></div>'
            f'<div style="display:flex;justify-content:space-between;padding:6px 0">'
            f'<span style="color:#888">Status</span><span style="font-weight:600">{wallet.Status}</span></div></div>', unsafe_allow_html=True)

with col2:
    st.markdown("### ✏️ Update Profile")
    with st.form("update_profile", clear_on_submit=False):
        new_name = st.text_input("Full Name", value=user.FullName)
        new_phone = st.text_input("Phone Number", value=user.PhoneNumber)
        submitted = st.form_submit_button("💾 Save Changes", use_container_width=True, type="primary")

    if submitted:
        if not new_name.strip() or not new_phone.strip():
            st.error("❌ Name and phone cannot be empty.")
        else:
            with st.spinner("Updating..."):
                try:
                    conn = get_connection()
                    cur = conn.cursor()
                    cur.execute("UPDATE [User] SET FullName=?, PhoneNumber=? WHERE UserID=?",
                        (new_name.strip(), new_phone.strip(), uid))
                    conn.commit()
                    conn.close()
                    st.session_state['user_name'] = new_name.strip()
                    st.success("✅ Profile updated successfully!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Update failed: {e}")
