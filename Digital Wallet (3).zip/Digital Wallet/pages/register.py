# register page - new user signup

import re
import streamlit as st
from db import get_connection
from utils.auth import hash_password
from utils.helpers import generate_wallet_number

# page config
st.set_page_config(page_title="Digital Wallet — Register", page_icon="💳", layout="wide", initial_sidebar_state="collapsed")

# css
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    [data-testid="collapsedControl"] { display: none; }
    html, body, [class*="st-"] { font-family: 'Inter', sans-serif; }
    
    .reg-header {
        background: linear-gradient(135deg, #0d3b1e 0%, #1A6B3C 50%, #2E8B57 100%);
        padding: 40px 30px;
        border-radius: 20px;
        color: white;
        text-align: center;
        margin-bottom: 30px;
        box-shadow: 0 12px 40px rgba(26,107,60,0.25);
    }
    .reg-header h1 { font-size: 32px; font-weight: 800; margin-bottom: 6px; }
    .reg-header p { font-size: 15px; opacity: 0.85; font-weight: 300; }
    
    div[data-testid="stForm"] { border: none !important; padding: 0 !important; }
</style>
""", unsafe_allow_html=True)

# header
st.markdown("""
<div class="reg-header">
    <h1>📝 Create Your Account</h1>
    <p>Join Digital Wallet — start sending money and paying bills in seconds</p>
</div>
""", unsafe_allow_html=True)

# form layout
col1, col2, col3 = st.columns([1, 2, 1])

with col2:
    with st.form("register_form", clear_on_submit=True):
        st.subheader("Personal Information")
        full_name = st.text_input("Full Name *", placeholder="e.g. Ahmed Khan")
        email = st.text_input("Email Address *", placeholder="you@example.com")

        c1, c2 = st.columns(2)
        with c1:
            phone = st.text_input("Phone Number *", placeholder="0300-1234567")
        with c2:
            cnic = st.text_input("CNIC *", placeholder="35201-1234567-1")

        st.subheader("Security")
        pwd = st.text_input("Password *", type="password", placeholder="Min 6 characters")
        confirm_pwd = st.text_input("Confirm Password *", type="password", placeholder="Re-enter your password")

        submitted = st.form_submit_button("🚀 Create Account", use_container_width=True, type="primary")

    if submitted:
        # validate inputs
        errors = []
        if not full_name.strip():
            errors.append("Full Name is required.")
        if not email.strip() or '@' not in email:
            errors.append("Valid email is required.")
        if not phone.strip():
            errors.append("Phone number is required.")
        if not cnic.strip():
            errors.append("CNIC is required.")
        if not re.match(r'^\d{5}-\d{7}-\d{1}$', cnic.strip()):
            errors.append("CNIC must be in format XXXXX-XXXXXXX-X.")
        if len(pwd) < 6:
            errors.append("Password must be at least 6 characters.")
        if pwd != confirm_pwd:
            errors.append("Passwords do not match.")

        if errors:
            for e in errors:
                st.error(f"❌ {e}")
        else:
            with st.spinner("Creating your account..."):
                try:
                    conn = get_connection()
                    cur = conn.cursor()

                    # check if email already exists
                    cur.execute("SELECT UserID FROM [User] WHERE Email=?", (email.strip(),))
                    if cur.fetchone():
                        st.error("❌ An account with this email already exists.")
                        conn.close()
                    else:
                        pw_hash = hash_password(pwd)
                        wnum = generate_wallet_number()

                        # insert user, wallet, notification together
                        try:
                            # insert user and get new id
                            cur.execute(
                                "INSERT INTO [User] (FullName, Email, PhoneNumber, CNIC, PasswordHash) OUTPUT INSERTED.UserID VALUES (?,?,?,?,?)",
                                (full_name.strip(), email.strip(), phone.strip(), cnic.strip(), pw_hash)
                            )
                            new_uid = cur.fetchone()[0]

                            # create wallet
                            cur.execute(
                                "INSERT INTO Wallet (UserID, WalletNumber) VALUES (?, ?)",
                                (new_uid, wnum)
                            )

                            # welcome notification
                            cur.execute(
                                "INSERT INTO Notification (UserID, Message, Type) VALUES (?, 'Welcome to Digital Wallet!', 'System')",
                                (new_uid,)
                            )

                            conn.commit()
                            conn.close()

                            st.success(f"✅ Account created successfully! Your wallet number is **{wnum}**")
                            st.info("🔑 You can now log in with your email and password.")
                            st.balloons()

                        except Exception as inner_e:
                            try:
                                conn.rollback()
                            except:
                                pass
                            conn.close()
                            st.error(f"❌ Registration failed: {inner_e}")

                except Exception as e:
                    st.error(f"❌ Database error: {e}")

    st.markdown("---")
    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown("**Already have an account?**")
    with col_b:
        if st.button("🔓 Sign In", use_container_width=True):
            st.switch_page("app.py")
