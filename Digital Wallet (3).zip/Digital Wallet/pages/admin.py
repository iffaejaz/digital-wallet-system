# admin panel - manage users and bill types

import streamlit as st
import pandas as pd
from db import get_connection
from utils.auth import check_admin
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — Admin", page_icon="⚙️", layout="wide")
check_admin()
render_sidebar()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
html,body,[class*="st-"]{font-family:'Inter',sans-serif}
.ah{background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460);padding:30px;border-radius:18px;color:#fff;text-align:center;margin-bottom:25px;box-shadow:0 10px 35px rgba(15,52,96,.35)}
.ah h2{font-weight:800;margin-bottom:4px}.ah p{opacity:.8;font-size:14px}
</style>
<div class="ah"><h2>⚙️ Admin Panel</h2><p>Manage users, wallets, and bill types</p></div>
""", unsafe_allow_html=True)

tab_users, tab_bills = st.tabs(["👥 User Management", "🧾 Bill Type Management"])

# user management tab
with tab_users:
    st.markdown("### 👥 All Users")
    with st.spinner("Loading users..."):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT UserID, FullName, Email, PhoneNumber, Role, IsActive, CreatedAt "
                "FROM [User] ORDER BY CreatedAt DESC")
            users = cur.fetchall()
            conn.close()
        except Exception as e:
            st.error(f"❌ Error: {e}")
            users = []

    if users:
        df = pd.DataFrame(
            [(u.UserID, u.FullName, u.Email, u.PhoneNumber, u.Role,
              "✅ Active" if u.IsActive else "❌ Suspended",
              u.CreatedAt.strftime('%d %b %Y')) for u in users],
            columns=["ID", "Name", "Email", "Phone", "Role", "Status", "Joined"])
        st.dataframe(df, use_container_width=True, hide_index=True)

        # suspend or activate user
        st.markdown("---")
        st.markdown("### 🔒 Suspend / Activate User")
        non_admin = [u for u in users if u.Role != 'Admin']
        if non_admin:
            user_opts = {f"{u.FullName} ({u.Email})": u for u in non_admin}
            selected = st.selectbox("Select User", list(user_opts.keys()))
            sel_usr = user_opts[selected]

            c1, c2 = st.columns(2)
            with c1:
                if st.button("❌ Suspend User", use_container_width=True, type="secondary"):
                    try:
                        conn = get_connection()
                        cur = conn.cursor()
                        cur.execute("UPDATE [User] SET IsActive=0 WHERE UserID=?", (sel_usr.UserID,))
                        cur.execute("UPDATE Wallet SET Status='Suspended' WHERE UserID=?", (sel_usr.UserID,))
                        conn.commit(); conn.close()
                        st.success(f"✅ {sel_usr.FullName} has been suspended.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error: {e}")
            with c2:
                if st.button("✅ Activate User", use_container_width=True, type="primary"):
                    try:
                        conn = get_connection()
                        cur = conn.cursor()
                        cur.execute("UPDATE [User] SET IsActive=1 WHERE UserID=?", (sel_usr.UserID,))
                        cur.execute("UPDATE Wallet SET Status='Active' WHERE UserID=?", (sel_usr.UserID,))
                        conn.commit(); conn.close()
                        st.success(f"✅ {sel_usr.FullName} has been activated.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error: {e}")

# bill type management tab
with tab_bills:
    st.markdown("### 🧾 Bill Types")
    with st.spinner("Loading..."):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT BillTypeID, TypeName, Description, ServiceCharge FROM BillType")
            bts = cur.fetchall()
            conn.close()
        except Exception as e:
            st.error(f"❌ Error: {e}")
            bts = []

    if bts:
        df_bt = pd.DataFrame(
            [(b.BillTypeID, b.TypeName, b.Description or 'N/A', f"PKR {b.ServiceCharge:,.2f}") for b in bts],
            columns=["ID", "Type", "Description", "Service Charge"])
        st.dataframe(df_bt, use_container_width=True, hide_index=True)

    # add new bill type
    st.markdown("---")
    st.markdown("### ➕ Add New Bill Type")
    with st.form("add_bill_type"):
        c1, c2, c3 = st.columns(3)
        with c1:
            new_type = st.text_input("Type Name", placeholder="e.g. Water")
        with c2:
            new_desc = st.text_input("Description", placeholder="Water bill payment")
        with c3:
            new_charge = st.number_input("Service Charge (PKR)", min_value=0.0, value=15.0, step=5.0)
        add_btn = st.form_submit_button("➕ Add Bill Type", use_container_width=True, type="primary")

    if add_btn:
        if not new_type.strip():
            st.error("❌ Type name is required.")
        else:
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("INSERT INTO BillType(TypeName,Description,ServiceCharge) VALUES(?,?,?)",
                    (new_type.strip(), new_desc.strip() or None, new_charge))
                conn.commit(); conn.close()
                st.success(f"✅ Bill type '{new_type.strip()}' added!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error: {e}")

    # update service charge
    if bts:
        st.markdown("---")
        st.markdown("### ✏️ Update Service Charge")
        bt_opts = {b.TypeName: b for b in bts}
        sel_bt = st.selectbox("Select Bill Type", list(bt_opts.keys()), key="upd_bt")
        new_sc = st.number_input("New Service Charge (PKR)", min_value=0.0,
                                  value=float(bt_opts[sel_bt].ServiceCharge), step=5.0, key="upd_sc")
        if st.button("💾 Update Charge", use_container_width=True):
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("UPDATE BillType SET ServiceCharge=? WHERE BillTypeID=?",
                            (new_sc, bt_opts[sel_bt].BillTypeID))
                conn.commit(); conn.close()
                st.success(f"✅ Service charge for {sel_bt} updated to PKR {new_sc:,.2f}")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error: {e}")
