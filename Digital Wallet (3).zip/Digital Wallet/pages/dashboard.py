# BI dashboard - admin only
# all 9 queries with charts

import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from db import get_connection

st.set_page_config(page_title="Digital Wallet — Dashboard", page_icon="📊", layout="wide")

# check login
if 'user_id' not in st.session_state:
    st.switch_page("app.py")

# admin only
if st.session_state.get('role') != 'Admin':
    st.error("Admin access only")
    st.stop()

st.title("📊 Admin Dashboard")
st.divider()

# ---- top level KPI metrics ----
try:
    conn = get_connection()
    cur = conn.cursor()

    # total users
    cur.execute("SELECT COUNT(*) FROM [User]")
    total_users = cur.fetchone()[0]

    # total transactions
    cur.execute("SELECT COUNT(*) FROM [Transaction]")
    total_txns = cur.fetchone()[0]

    # total revenue (sum of all bill payments)
    cur.execute("SELECT ISNULL(SUM(TotalDeducted), 0) FROM BillPayment")
    total_revenue = cur.fetchone()[0]

    # active wallets
    cur.execute("SELECT COUNT(*) FROM Wallet WHERE Status = 'Active'")
    active_wallets = cur.fetchone()[0]

    conn.close()
except Exception as e:
    st.error(f"Error loading metrics: {e}")
    st.stop()

# show 4 metric cards
m1, m2, m3, m4 = st.columns(4)
m1.metric("Total Users", total_users)
m2.metric("Total Transactions", total_txns)
m3.metric("Total Revenue", f"PKR {total_revenue:,.0f}")
m4.metric("Active Wallets", active_wallets)

st.divider()


# ============================================
# QUERY 1 - Complete Transaction Report
# 4 table JOIN (User, Wallet sender, Wallet receiver, Transaction)
# ============================================
st.subheader("📋 Query 1: Full Transaction Report")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select u1.FullName as Sender, u1.Email as SenderEmail,
               w1.Balance as SenderBalance, t.Amount,
               'Debit' as TransactionType, t.Status,
               t.TransactionDate,
               u2.FullName as Receiver
        from [User] u1
        join Wallet w1 on u1.UserID = w1.UserID
        join [Transaction] t on w1.WalletID = t.SenderWalletID
        join Wallet w2 on t.ReceiverWalletID = w2.WalletID
        join [User] u2 on w2.UserID = u2.UserID
        order by t.TransactionDate desc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No transactions found.")
except Exception as e:
    st.error(f"Query 1 error: {e}")


# ============================================
# QUERY 2 - Bill Payment Full Report
# 3 table JOIN (BillPayment, User via Wallet, BillType)
# ============================================
st.subheader("🧾 Query 2: Bill Payment Full Report")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select u.FullName, bt.TypeName,
               bp.Amount, bp.Status, bp.PaymentDate
        from BillPayment bp
        join Wallet w on bp.WalletID = w.WalletID
        join [User] u on w.UserID = u.UserID
        join BillType bt on bp.BillTypeID = bt.BillTypeID
        order by bp.PaymentDate desc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No bill payments found.")
except Exception as e:
    st.error(f"Query 2 error: {e}")


# ============================================
# QUERY 3 - Top Spenders
# GROUP BY + HAVING + subquery
# ============================================
st.subheader("🏆 Query 3: Top Spenders")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select u.FullName,
               sum(t.Amount) as TotalSpent,
               count(*) as TxnCount
        from [User] u
        join Wallet w on u.UserID = w.UserID
        join [Transaction] t on w.WalletID = t.SenderWalletID
        group by u.UserID, u.FullName
        having sum(t.Amount) > (
            select avg(sub.TotalAmt)
            from (
                select sum(t2.Amount) as TotalAmt
                from [Transaction] t2
                group by t2.SenderWalletID
            ) sub
        )
        order by TotalSpent desc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
        # bar chart
        fig = px.bar(df, x='FullName', y='TotalSpent',
                     title='Top Spenders')
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No top spenders data.")
except Exception as e:
    st.error(f"Query 3 error: {e}")


# ============================================
# QUERY 4 - Monthly Transaction Volume
# GROUP BY + FORMAT date
# ============================================
st.subheader("📈 Query 4: Monthly Transaction Volume")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select FORMAT(t.TransactionDate, 'yyyy-MM') as Month,
               count(*) as TotalTxns,
               sum(t.Amount) as TotalAmount
        from [Transaction] t
        group by FORMAT(t.TransactionDate, 'yyyy-MM')
        order by Month
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
        # line chart
        fig = px.line(df, x='Month', y='TotalAmount',
                      title='Monthly Volume')
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No monthly data.")
except Exception as e:
    st.error(f"Query 4 error: {e}")


# ============================================
# QUERY 5 - Bill Revenue by Category
# GROUP BY + HAVING
# ============================================
st.subheader("💰 Query 5: Bill Revenue by Category")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select bt.TypeName,
               count(*) as TotalBills,
               sum(bp.Amount) as Revenue
        from BillPayment bp
        join BillType bt on bp.BillTypeID = bt.BillTypeID
        group by bt.BillTypeID, bt.TypeName
        having count(*) > 1
        order by Revenue desc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
        # pie chart
        fig = px.pie(df, names='TypeName', values='Revenue',
                     title='Bill Revenue by Category')
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No bill revenue data.")
except Exception as e:
    st.error(f"Query 5 error: {e}")


# ============================================
# QUERY 6 - Users Below Average Balance
# WHERE subquery
# ============================================
st.subheader("⚠️ Query 6: Users Below Average Balance")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select u.FullName, u.Email, w.Balance
        from [User] u
        join Wallet w on u.UserID = w.UserID
        where w.Balance < (
            select avg(Balance) from Wallet
        )
        order by w.Balance asc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        st.warning("These users have below average balance")
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No users below average balance.")
except Exception as e:
    st.error(f"Query 6 error: {e}")


# ============================================
# QUERY 7 - High Activity Wallets
# FROM subquery / derived table
# ============================================
st.subheader("🔥 Query 7: High Activity Wallets")
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select u.FullName, sub.WalletID,
               sub.TxnCount, sub.TotalAmt
        from (
            select t.SenderWalletID as WalletID,
                   count(*) as TxnCount,
                   sum(t.Amount) as TotalAmt
            from [Transaction] t
            group by t.SenderWalletID
            having count(*) >= 2
        ) sub
        join Wallet w on sub.WalletID = w.WalletID
        join [User] u on w.UserID = u.UserID
        order by sub.TxnCount desc
    """)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No high activity wallets.")
except Exception as e:
    st.error(f"Query 7 error: {e}")


# ============================================
# QUERY 8 - Search by name (LIKE)
# ============================================
st.subheader("🔍 Query 8: Search by Name")
search = st.text_input("🔍 Search by name")

if search:
    try:
        conn = get_connection()
        cur = conn.cursor()
        param = f"%{search}%"
        cur.execute("""
            select u.FullName, u.Email, w.Balance,
                   t.Amount, t.TransactionDate, t.ReferenceNumber
            from [User] u
            join Wallet w on u.UserID = w.UserID
            join [Transaction] t on w.WalletID = t.SenderWalletID
            where u.FullName like ?
            order by t.TransactionDate desc
        """, (param,))
        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]
        conn.close()
        if rows:
            df = pd.DataFrame.from_records(rows, columns=cols)
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.warning("No results found.")
    except Exception as e:
        st.error(f"Query 8 error: {e}")
else:
    st.info("Enter a name to search")


# ============================================
# QUERY 9 - Date Range + DISTINCT users
# BETWEEN + DISTINCT
# ============================================
st.subheader("📅 Query 9: Date Range Filter")
col1, col2 = st.columns(2)
start = col1.date_input("From Date", value=datetime.now() - timedelta(days=365), key="q9_start")
end = col2.date_input("To Date", value=datetime.now(), key="q9_end")

try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        select distinct u.FullName, u.Email,
               count(t.TransactionID) as TxnCount
        from [User] u
        join Wallet w on u.UserID = w.UserID
        join [Transaction] t on w.WalletID = t.SenderWalletID
        where cast(t.TransactionDate as date) between ? and ?
        group by u.UserID, u.FullName, u.Email
        order by TxnCount desc
    """, (start, end))
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    conn.close()
    if rows:
        df = pd.DataFrame.from_records(rows, columns=cols)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No transactions in this date range.")
except Exception as e:
    st.error(f"Query 9 error: {e}")
