# wallet page - view balance and topup

import streamlit as st
from db import get_connection
from utils.auth import check_session
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — My Wallet", page_icon="💰", layout="wide")
check_session()
render_sidebar()

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    html, body, [class*="st-"] { font-family: 'Inter', sans-serif; }
    .wallet-hero {background: linear-gradient(135deg, #0d3b1e, #1A6B3C 40%, #2E8B57 70%, #3CB371);
        padding: 45px 40px;border-radius: 22px;color: white;box-shadow: 0 16px 50px rgba(26,107,60,0.3);
        position: relative;overflow: hidden;}
    .wallet-hero::after {content: '';position: absolute;top: -30%;right: -10%;width: 300px;height: 300px;
        border-radius: 50%;background: rgba(255,255,255,0.05);}
    .wallet-label { font-size: 13px; text-transform: uppercase; letter-spacing: 2px; opacity: 0.75; }
    .wallet-balance { font-size: 48px; font-weight: 900; margin: 8px 0; letter-spacing: -1px; }
    .wallet-number { font-size: 15px; opacity: 0.8; font-family: monospace; }
    .wallet-status {display: inline-block;background: rgba(255,255,255,0.2);padding: 4px 14px;
        border-radius: 20px;font-size: 12px;font-weight: 600;margin-top: 10px;}
    .info-card {background: white;border: 1px solid #e8f5ee;border-radius: 16px;padding: 24px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.04);text-align: center;}
    .info-card .label { color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; }
    .info-card .value { color: #1A6B3C; font-size: 22px; font-weight: 700; margin-top: 6px; }
    .recent-txn {background: #f9fdfb;border-left: 4px solid #1A6B3C;padding: 14px 20px;
        border-radius: 0 12px 12px 0;margin-bottom: 10px;}
    div[data-testid="column"] button[kind="secondary"] {border: 2px solid #1A6B3C !important;
        background: white !important;color: #1A6B3C !important;font-weight: 600 !important;
        padding: 12px 8px !important;border-radius: 8px !important;font-size: 14px !important;}
    div[data-testid="column"] button[kind="secondary"]:hover {background: #f0faf4 !important;}
</style>
""", unsafe_allow_html=True)

st.markdown("## 💰 My Wallet")

# get wallet data
with st.spinner("Loading wallet..."):
    try:
        conn = get_connection()
        cur = conn.cursor()
        uid = int(st.session_state.get('user_id', 0))
        cur.execute("SELECT w.WalletID, w.WalletNumber, w.Balance, w.Status, w.Currency, w.CreatedAt "
            "FROM Wallet w WHERE w.UserID=?", (uid,))
        wallet = cur.fetchone()
        if not wallet:
            st.error('Session expired. Please login again.')
            st.stop()

        # recent txns
        cur.execute("SELECT TOP 5 t.ReferenceNumber, t.Amount, t.TransactionDate, t.Status, t.Description, "
            "CASE WHEN t.SenderWalletID=? THEN 'Sent' ELSE 'Received' END AS Direction "
            "FROM [Transaction] t WHERE t.SenderWalletID=? OR t.ReceiverWalletID=? "
            "ORDER BY t.TransactionDate DESC", (wallet.WalletID, wallet.WalletID, wallet.WalletID))
        recent_txns = cur.fetchall()

        # sent count
        cur.execute("SELECT COUNT(*) FROM [Transaction] WHERE SenderWalletID=? AND Status='Success'", (wallet.WalletID,))
        sent_count = cur.fetchone()[0]
        # received count
        cur.execute("SELECT COUNT(*) FROM [Transaction] WHERE ReceiverWalletID=? AND Status='Success'", (wallet.WalletID,))
        received_count = cur.fetchone()[0]
        # total bills
        cur.execute("SELECT ISNULL(SUM(TotalDeducted), 0) FROM BillPayment WHERE WalletID=? AND Status='Success'", (wallet.WalletID,))
        total_bills = cur.fetchone()[0]
        conn.close()
    except Exception as e:
        st.error(f"❌ Error loading wallet: {e}")
        st.stop()

if not wallet:
    st.error("⚠️ No wallet found.")
    st.stop()

# hero card
st.markdown(f'<div class="wallet-hero"><div class="wallet-label">Available Balance</div>'
    f'<div class="wallet-balance">{wallet.Currency} {wallet.Balance:,.2f}</div>'
    f'<div class="wallet-number">Wallet: {wallet.WalletNumber}</div>'
    f'<div class="wallet-status">● {wallet.Status}</div></div>', unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)

# stats
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="info-card"><div class="label">💸 Sent</div><div class="value">{sent_count}</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="info-card"><div class="label">📥 Received</div><div class="value">{received_count}</div></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="info-card"><div class="label">🧾 Bills Paid</div><div class="value">PKR {total_bills:,.0f}</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="info-card"><div class="label">📅 Member Since</div><div class="value">{wallet.CreatedAt.strftime("%b %Y")}</div></div>', unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# tabs
tab_topup, tab_recent = st.tabs(["💳 Top-Up Wallet", "📜 Recent Activity"])

with tab_topup:
    st.markdown("### Add Money to Your Wallet")
    col_a, col_b = st.columns([2, 1])
    with col_a:
        st.markdown("**Quick Amounts**")
        qc1, qc2, qc3, qc4 = st.columns(4)
        def set_amount(val):
            st.session_state.topup_amount = val
        with qc1:
            st.button("PKR 500", use_container_width=True, key="q500", on_click=set_amount, args=(500.0,))
        with qc2:
            st.button("PKR 1,000", use_container_width=True, key="q1000", on_click=set_amount, args=(1000.0,))
        with qc3:
            st.button("PKR 5,000", use_container_width=True, key="q5000", on_click=set_amount, args=(5000.0,))
        with qc4:
            st.button("PKR 10,000", use_container_width=True, key="q10000", on_click=set_amount, args=(10000.0,))

        if 'topup_amount' not in st.session_state:
            st.session_state.topup_amount = 100.0
        amt = st.number_input("Or enter custom amount (PKR)", min_value=1.0, max_value=500000.0, step=100.0, key="topup_amount")

        if st.button("✅ Add Money", use_container_width=True, type="primary", key="topup_btn"):
            if amt <= 0:
                st.error("❌ Enter a valid amount.")
            elif wallet.Status != 'Active':
                st.error("❌ Your wallet is not active.")
            else:
                with st.spinner("Processing top-up..."):
                    try:
                        conn = get_connection()
                        cur = conn.cursor()
                        cur.execute("UPDATE Wallet SET Balance = Balance + ? WHERE WalletID=? AND Status='Active'", (amt, wallet.WalletID))
                        cur.execute("INSERT INTO Notification (UserID, Message, Type) VALUES (?, ?, 'System')",
                            (int(st.session_state.get('user_id', 0)), f"PKR {amt:,.2f} added to your wallet."))
                        conn.commit()
                        conn.close()
                        st.success(f"✅ PKR {amt:,.2f} added successfully!")
                        st.balloons()
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Top-up failed: {e}")

    with col_b:
        st.markdown(f'<div class="info-card" style="margin-top: 30px;"><div class="label">Current Balance</div>'
            f'<div class="value">PKR {wallet.Balance:,.2f}</div></div>', unsafe_allow_html=True)

with tab_recent:
    st.markdown("### Recent Transactions")
    if recent_txns:
        for txn in recent_txns:
            icon = "🔴" if txn.Direction == "Sent" else "🟢"
            sign = "-" if txn.Direction == "Sent" else "+"
            clr = '#dc3545' if txn.Direction == 'Sent' else '#1A6B3C'
            st.markdown(f'<div class="recent-txn"><div style="display:flex; justify-content:space-between; align-items:center;">'
                f'<div><strong>{icon} {txn.Direction}</strong> — {txn.Description or "N/A"}'
                f'<div style="font-size:12px; color:#888;">{txn.ReferenceNumber} • {txn.TransactionDate.strftime("%d %b %Y, %I:%M %p")}</div></div>'
                f'<div style="font-size:18px; font-weight:700; color:{clr};">{sign} PKR {txn.Amount:,.2f}</div>'
                f'</div></div>', unsafe_allow_html=True)
    else:
        st.info("📭 No transactions yet.")
    if st.button("📜 View Full History", use_container_width=True):
        st.switch_page("pages/history.py")