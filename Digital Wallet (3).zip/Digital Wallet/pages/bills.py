# bills page - pay utility bills

import streamlit as st
import pandas as pd
from db import get_connection
from utils.auth import check_session
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — Bills", page_icon="🧾", layout="wide")
check_session()
render_sidebar()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
html,body,[class*="st-"]{font-family:'Inter',sans-serif}
.bh{background:linear-gradient(135deg,#0d3b1e,#1A6B3C,#2E8B57);padding:30px;border-radius:18px;color:#fff;text-align:center;margin-bottom:25px;box-shadow:0 10px 35px rgba(26,107,60,.25)}
.bh h2{font-weight:800;margin-bottom:4px}.bh p{opacity:.8;font-size:14px}
.bill-summary{background:#f0faf4;border:1px solid #1A6B3C;border-radius:14px;padding:20px;margin:15px 0}
</style>
<div class="bh"><h2>🧾 Bill Payments</h2><p>Pay your utility bills instantly from your wallet</p></div>
""", unsafe_allow_html=True)

tab_pay, tab_history = st.tabs(["💳 Pay Bill", "📜 Payment History"])

# pay a bill
with tab_pay:
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown("### Pay a Bill")
        # get bill types
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT BillTypeID, TypeName, ServiceCharge FROM BillType")
            bill_types = cur.fetchall()
            conn.close()
        except Exception as e:
            st.error(f"❌ Error loading bill types: {e}")
            bill_types = []

        if bill_types:
            bt_names = [bt.TypeName for bt in bill_types]
            selected = st.selectbox("Bill Type", bt_names, key="bill_type")
            consumer_num = st.text_input("Consumer / Account Number", placeholder="e.g. ELEC-001234")
            bill_amt = st.number_input("Bill Amount (PKR)", min_value=1.0, max_value=500000.0, value=500.0, step=50.0)

            # get service charge
            bt_obj = next(bt for bt in bill_types if bt.TypeName == selected)
            scharge = float(bt_obj.ServiceCharge)
            total = bill_amt + scharge

            st.markdown(f'<div class="bill-summary"><strong>Bill Summary</strong><br>'
                f'<div style="display:flex;justify-content:space-between;margin-top:10px">'
                f'<span>Bill Amount:</span><span>PKR {bill_amt:,.2f}</span></div>'
                f'<div style="display:flex;justify-content:space-between">'
                f'<span>Service Charge:</span><span>PKR {scharge:,.2f}</span></div>'
                f'<hr style="margin:8px 0">'
                f'<div style="display:flex;justify-content:space-between;font-weight:700;font-size:18px">'
                f'<span>Total:</span><span style="color:#1A6B3C">PKR {total:,.2f}</span></div></div>', unsafe_allow_html=True)

            if st.button("✅ Pay Bill", use_container_width=True, type="primary"):
                if not consumer_num.strip():
                    st.error("❌ Enter consumer number.")
                else:
                    with st.spinner("Processing payment..."):
                        try:
                            conn = get_connection()
                            cur = conn.cursor()
                            wid = int(st.session_state.get('wallet_id', 0))
                            try:
                                # deduct from wallet
                                cur.execute("UPDATE Wallet SET Balance=Balance-? WHERE WalletID=? AND Balance>=?", (total, wid, total))
                                if cur.rowcount == 0:
                                    raise Exception("Insufficient balance")
                                # insert bill payment
                                cur.execute("INSERT INTO BillPayment(WalletID,BillTypeID,ConsumerNumber,Amount,ServiceCharge,TotalDeducted) "
                                    "VALUES(?,?,?,?,?,?)", (wid, bt_obj.BillTypeID, consumer_num.strip(), bill_amt, scharge, total))
                                # add notif
                                cur.execute("INSERT INTO Notification(UserID,Message,Type) VALUES(?,?,'BillPayment')",
                                    (int(st.session_state.get('user_id', 0)),
                                     f"{selected} bill paid. Amount: PKR {total:,.2f}. Consumer: {consumer_num.strip()}"))
                                conn.commit()
                                conn.close()
                                st.success(f"✅ {selected} bill paid successfully! Total deducted: PKR {total:,.2f}")
                                st.balloons()
                                st.rerun()
                            except Exception as ie:
                                try: conn.rollback()
                                except: pass
                                conn.close()
                                st.error(f"❌ Payment failed: {ie}")
                        except Exception as e:
                            st.error(f"❌ Error: {e}")

    with col2:
        st.markdown("### 💡 Quick Info")
        st.info("🔌 **Electricity** — WAPDA / LESCO")
        st.info("🔥 **Gas** — SNGPL / SSGC")
        st.info("🌐 **Internet** — Broadband providers")
        st.info("📱 **Mobile** — Top-up & recharge")
        try:
            conn = get_connection(); cur = conn.cursor()
            cur.execute("SELECT Balance FROM Wallet WHERE WalletID=?", (int(st.session_state.get('wallet_id', 0)),))
            b = cur.fetchone(); conn.close()
            if b:
                st.metric("Wallet Balance", f"PKR {b[0]:,.2f}")
        except Exception:
            pass

# payment history tab
with tab_history:
    st.markdown("### 📜 Bill Payment History")
    with st.spinner("Loading..."):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT bt.TypeName, bp.ConsumerNumber, bp.Amount, bp.ServiceCharge, "
                "bp.TotalDeducted, bp.PaymentDate, bp.Status "
                "FROM BillPayment bp JOIN BillType bt ON bp.BillTypeID=bt.BillTypeID "
                "WHERE bp.WalletID=(SELECT WalletID FROM Wallet WHERE UserID=?) "
                "ORDER BY bp.PaymentDate DESC", (int(st.session_state.get('user_id', 0)),))
            rows = cur.fetchall()
            conn.close()
            if rows:
                df = pd.DataFrame(
                    [(r.TypeName, r.ConsumerNumber, f"PKR {r.Amount:,.2f}",
                      f"PKR {r.ServiceCharge:,.2f}", f"PKR {r.TotalDeducted:,.2f}",
                      r.PaymentDate.strftime('%d %b %Y, %I:%M %p'), r.Status) for r in rows],
                    columns=["Type","Consumer No.","Amount","Service Charge","Total","Date","Status"])
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("📭 No bill payments yet.")
        except Exception as e:
            st.error(f"❌ Error: {e}")
