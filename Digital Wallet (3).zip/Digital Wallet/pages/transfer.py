# transfer page - send money to other users

import streamlit as st
import pyodbc
import random
import string
from datetime import datetime

st.set_page_config(page_title="Send Money", page_icon="💸", layout="wide")

# check login
if not st.session_state.get('user_id'):
    st.error("Please login first!")
    st.switch_page("app.py")
    st.stop()

uid = int(st.session_state['user_id'])

from db import get_connection

# generate ref number
def generate_ref():
    now = datetime.now()
    r = ''.join(random.choices(string.digits, k=4))
    return f"TXN-{now.year}{now.month:02d}{now.day:02d}{r}"

from utils.helpers import render_sidebar
render_sidebar()

# css
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
html,body,[class*="st-"]{font-family:'Inter',sans-serif}
.header{background:linear-gradient(135deg,#0d3b1e,#1A6B3C,#2E8B57);padding:30px;border-radius:18px;color:#fff;text-align:center;margin-bottom:25px;}
.header h2{font-weight:800;margin-bottom:4px}
.header p{opacity:.8;font-size:14px;margin:0}
.balance-box{background:#f0faf4;border:2px solid #1A6B3C;border-radius:12px;padding:20px;text-align:center;margin-bottom:20px;}
.balance-box h2{color:#1A6B3C;font-size:28px;margin:5px 0;}
.success-box{background:#e8f5e9;border:2px solid #2E8B57;border-radius:12px;padding:20px;margin-top:15px;}
div[data-testid="column"] button[kind="secondary"] {border: 2px solid #1A6B3C !important;
    background: white !important;color: #1A6B3C !important;font-weight: 600 !important;
    padding: 12px 8px !important;border-radius: 8px !important;font-size: 14px !important;}
div[data-testid="column"] button[kind="secondary"]:hover {background: #f0faf4 !important;}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="header"><h2>💸 Money Transfer</h2><p>Send money instantly to any Digital Wallet user</p></div>', unsafe_allow_html=True)

# get sender wallet
try:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT w.WalletID, w.Balance, w.WalletNumber, w.Status FROM Wallet w WHERE w.UserID = ?", (uid,))
    sw = cur.fetchone()
    conn.close()
    if not sw:
        st.error("❌ No wallet found.")
        st.stop()
    sw_id = int(sw[0])
    sw_bal = float(sw[1])
    sw_num = str(sw[2])
    sw_status = str(sw[3])
    if sw_status != 'Active':
        st.error(f"❌ Your wallet is {sw_status}. Cannot send money.")
        st.stop()
except Exception as e:
    st.error(f"❌ Database error: {e}")
    st.stop()

tab_send, tab_received = st.tabs(["📤 Send Money", "📥 Received Money"])

with tab_send:
    col_form, col_info = st.columns([2, 1])
    with col_form:
        # show balance
        st.markdown(f'<div class="balance-box"><p style="color:#666;margin:0;font-size:13px;">YOUR AVAILABLE BALANCE</p>'
            f'<h2>PKR {sw_bal:,.2f}</h2><p style="color:#888;margin:0;font-size:12px;">Wallet: {sw_num}</p></div>', unsafe_allow_html=True)

        # quick amounts
        st.markdown("### Quick Amounts")
        if 'selected_amount' not in st.session_state:
            st.session_state.selected_amount = 100.0
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("PKR 500", key="quick_500", use_container_width=True):
                st.session_state.selected_amount = 500.0
                st.rerun()
        with col2:
            if st.button("PKR 1,000", key="quick_1000", use_container_width=True):
                st.session_state.selected_amount = 1000.0
                st.rerun()
        with col3:
            if st.button("PKR 5,000", key="quick_5000", use_container_width=True):
                st.session_state.selected_amount = 5000.0
                st.rerun()
        with col4:
            if st.button("PKR 10,000", key="quick_10000", use_container_width=True):
                st.session_state.selected_amount = 10000.0
                st.rerun()

        st.markdown("---")
        st.markdown("### Send Money")
        recv_wnum = st.text_input("Receiver Wallet Number *", placeholder="e.g. DW-20250002")
        amt = st.number_input("Amount (PKR) *", min_value=1.0, max_value=max(sw_bal, 1.0),
            value=st.session_state.selected_amount, step=100.0)
        desc = st.text_input("Description (optional)", placeholder="e.g. Rent payment")

        if st.button("💸 Send Money", use_container_width=True, type="primary"):
            if not recv_wnum.strip():
                st.error("❌ Please enter receiver wallet number.")
            elif recv_wnum.strip() == sw_num:
                st.error("❌ Cannot send money to your own wallet.")
            elif amt <= 0:
                st.error("❌ Amount must be greater than 0.")
            elif amt > sw_bal:
                st.error(f"❌ Insufficient balance. Available: PKR {sw_bal:,.2f}")
            else:
                with st.spinner("Processing transfer..."):
                    conn = None
                    try:
                        conn = get_connection()
                        cur = conn.cursor()
                        conn.autocommit = False

                        # find receiver
                        cur.execute("SELECT w.WalletID, w.Status, u.FullName, u.UserID FROM Wallet w "
                            "JOIN [User] u ON w.UserID = u.UserID WHERE w.WalletNumber = ?", (recv_wnum.strip(),))
                        recv = cur.fetchone()

                        if not recv:
                            st.error("❌ Receiver wallet not found.")
                            conn.autocommit = True
                            conn.close()
                        elif str(recv[1]) != 'Active':
                            st.error("❌ Receiver wallet is not active.")
                            conn.autocommit = True
                            conn.close()
                        else:
                            recv_wid = int(recv[0])
                            recv_name = str(recv[2])
                            recv_uid = int(recv[3])

                            # deduct from sender
                            cur.execute("UPDATE Wallet SET Balance = Balance - ? WHERE WalletID = ? AND Balance >= ?",
                                (amt, sw_id, amt))
                            if cur.rowcount == 0:
                                raise Exception("Deduction failed — not enough balance.")

                            # credit receiver
                            cur.execute("UPDATE Wallet SET Balance = Balance + ? WHERE WalletID = ?", (amt, recv_wid))

                            # insert txn record
                            ref = generate_ref()
                            txn_desc = desc.strip() if desc.strip() else f"Transfer to {recv_name}"
                            cur.execute("INSERT INTO [Transaction] (SenderWalletID, ReceiverWalletID, Amount, Description, Status, ReferenceNumber) "
                                "VALUES (?, ?, ?, ?, 'Success', ?)", (sw_id, recv_wid, amt, txn_desc, ref))

                            # get txn id for log
                            cur.execute("SELECT @@IDENTITY")
                            tid_row = cur.fetchone()
                            tid = int(tid_row[0]) if tid_row else 0

                            # sender notif
                            cur.execute("INSERT INTO Notification (UserID, Message, Type) VALUES (?, ?, 'Transfer')",
                                (uid, f"You sent PKR {amt:,.2f} to {recv_name}. Ref: {ref}"))
                            # receiver notif
                            sname = st.session_state.get('user_name', 'Someone')
                            cur.execute("INSERT INTO Notification (UserID, Message, Type) VALUES (?, ?, 'Transfer')",
                                (recv_uid, f"You received PKR {amt:,.2f} from {sname}. Ref: {ref}"))

                            # txn log
                            if tid > 0:
                                cur.execute("INSERT INTO TransactionLog (UserID, TransactionID, Action) VALUES (?, ?, 'Sent')", (uid, tid))
                                cur.execute("INSERT INTO TransactionLog (UserID, TransactionID, Action) VALUES (?, ?, 'Received')", (recv_uid, tid))

                            conn.commit()
                            conn.autocommit = True
                            conn.close()

                            new_bal = sw_bal - amt
                            st.markdown(f'<div class="success-box"><h3 style="color:#1A6B3C;margin:0">✅ Transfer Successful!</h3>'
                                f'<p style="margin:10px 0 0 0"><b>Reference:</b> {ref}</p>'
                                f'<p style="margin:5px 0"><b>To:</b> {recv_name}</p>'
                                f'<p style="margin:5px 0"><b>Amount:</b> PKR {amt:,.2f}</p>'
                                f'<p style="margin:5px 0"><b>New Balance:</b> PKR {new_bal:,.2f}</p></div>', unsafe_allow_html=True)
                            st.balloons()

                    except Exception as e:
                        if conn:
                            try:
                                conn.rollback()
                                conn.autocommit = True
                            except: pass
                            try: conn.close()
                            except: pass
                        st.error(f"❌ Transfer failed: {str(e)}")

    with col_info:
        st.markdown("### ℹ️ Transfer Tips")
        st.info("💡 Double-check wallet number before sending.")
        st.info("⚡ Transfers are instant and irreversible.")
        st.info("🔔 Both parties receive a notification.")
        st.metric("Your Balance", f"PKR {sw_bal:,.2f}")

with tab_received:
    st.markdown("### 📥 Incoming Transfers")
    with st.spinner("Loading..."):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT t.ReferenceNumber, u.FullName AS SenderName, t.Amount, t.TransactionDate, t.Status, t.Description "
                "FROM [Transaction] t JOIN Wallet w_send ON t.SenderWalletID = w_send.WalletID "
                "JOIN [User] u ON w_send.UserID = u.UserID WHERE t.ReceiverWalletID = ? "
                "ORDER BY t.TransactionDate DESC", (sw_id,))
            rows = cur.fetchall()
            conn.close()
            if rows:
                import pandas as pd
                df = pd.DataFrame([(r[0], r[1], f"PKR {float(r[2]):,.2f}",
                    r[3].strftime('%d %b %Y, %I:%M %p') if r[3] else '', r[4], r[5] or 'N/A')
                    for r in rows], columns=["Reference", "From", "Amount", "Date", "Status", "Description"])
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("📭 No incoming transfers yet.")
        except Exception as e:
            st.error(f"❌ Error loading received transfers: {e}")