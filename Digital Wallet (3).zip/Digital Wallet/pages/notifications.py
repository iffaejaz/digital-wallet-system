# notifications page

import streamlit as st
from db import get_connection
from utils.auth import check_session
from utils.helpers import render_sidebar

st.set_page_config(page_title="Digital Wallet — Notifications", page_icon="🔔", layout="wide")
check_session()
render_sidebar()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
html,body,[class*="st-"]{font-family:'Inter',sans-serif}
.nh{background:linear-gradient(135deg,#0d3b1e,#1A6B3C,#2E8B57);padding:30px;border-radius:18px;color:#fff;text-align:center;margin-bottom:25px;box-shadow:0 10px 35px rgba(26,107,60,.25)}
.nh h2{font-weight:800;margin-bottom:4px}.nh p{opacity:.8;font-size:14px}
.notif-item{padding:16px 20px;border-radius:12px;margin-bottom:10px;border:1px solid #e8f5ee;display:flex;align-items:flex-start;gap:14px}
.notif-unread{background:#f0faf4;border-left:4px solid #1A6B3C}
.notif-read{background:#fafafa;border-left:4px solid #ccc}
.notif-dot{width:10px;height:10px;border-radius:50%;margin-top:6px;flex-shrink:0}
.dot-green{background:#1A6B3C}.dot-grey{background:#ccc}
.notif-body{flex:1}
.notif-msg{font-size:14px;font-weight:500;color:#333}
.notif-meta{font-size:12px;color:#888;margin-top:4px}
.notif-badge{display:inline-block;background:#1A6B3C;color:#fff;padding:2px 10px;border-radius:12px;font-size:11px;font-weight:600}
</style>
<div class="nh"><h2>🔔 Notifications</h2><p>Stay updated with all your wallet activity</p></div>
""", unsafe_allow_html=True)

uid = int(st.session_state.get('user_id', 0))

# mark all as read btn
c1, c2 = st.columns([3, 1])
with c2:
    if st.button("✅ Mark All as Read", use_container_width=True, type="primary"):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("UPDATE Notification SET IsRead=1 WHERE UserID=? AND IsRead=0", (uid,))
            conn.commit()
            conn.close()
            st.success("All notifications marked as read!")
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error: {e}")

# get notifications
with st.spinner("Loading notifications..."):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT NotificationID, Message, Type, IsRead, CreatedAt "
            "FROM Notification WHERE UserID=? ORDER BY CreatedAt DESC", (uid,))
        notifs = cur.fetchall()
        cur.execute("SELECT COUNT(*) FROM Notification WHERE UserID=? AND IsRead=0", (uid,))
        unread_cnt = cur.fetchone()[0]
        conn.close()
    except Exception as e:
        st.error(f"❌ Error: {e}")
        notifs = []
        unread_cnt = 0

with c1:
    st.markdown(f"**{len(notifs)} notifications** — **{unread_cnt} unread**")

if notifs:
    # filter by type
    type_filter = st.selectbox("Filter by Type", ["All", "System", "Transfer", "BillPayment"], key="nf_type")

    for n in notifs:
        if type_filter != "All" and n.Type != type_filter:
            continue
        css_cls = "notif-unread" if not n.IsRead else "notif-read"
        dot_cls = "dot-green" if not n.IsRead else "dot-grey"
        icons = {"System": "⚙️", "Transfer": "💸", "BillPayment": "🧾"}
        icon = icons.get(n.Type, "🔔")

        st.markdown(f'<div class="notif-item {css_cls}"><div class="notif-dot {dot_cls}"></div>'
            f'<div class="notif-body"><div class="notif-msg">{icon} {n.Message}</div>'
            f'<div class="notif-meta"><span class="notif-badge">{n.Type}</span> • {n.CreatedAt.strftime("%d %b %Y, %I:%M %p")}'
            f'</div></div></div>', unsafe_allow_html=True)
else:
    st.info("📭 No notifications yet.")
