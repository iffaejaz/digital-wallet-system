# auth functions for login/register

import hashlib
import streamlit as st

# hash the password using sha256
def hash_password(pwd):
    return hashlib.sha256(pwd.encode('utf-8')).hexdigest()

# check if password matches
def verify_password(pwd, pwd_hash):
    return hash_password(pwd) == pwd_hash

# check if user is logged in
def check_session():
    if not st.session_state.get('user_id'):
        st.switch_page("app.py")

# check if user is admin
def check_admin():
    check_session()
    if st.session_state.get('role') != 'Admin':
        st.error("⛔ Access Denied. Admin only.")
        st.stop()

# logout and clear everything
def logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.switch_page("app.py")
