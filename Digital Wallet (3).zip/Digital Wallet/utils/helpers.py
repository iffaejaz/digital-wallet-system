# helper functions for the app

import random
import string
from datetime import datetime

import streamlit as st
from db import get_connection


# generate wallet number like DW-20250001
def generate_wallet_number():
    try:
        conn = get_connection()
        cur = conn.cursor()
        # get max wallet id
        cur.execute("SELECT MAX(WalletID) FROM Wallet")
        row = cur.fetchone()
        nxt = (row[0] or 0) + 1
        conn.close()
        return f"DW-{datetime.now().year}{nxt:04d}"
    except Exception:
        # fallback random number
        r = random.randint(1000, 9999)
        return f"DW-{datetime.now().year}{r}"


# generate txn reference number
def generate_reference():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT MAX(TransactionID) FROM [Transaction]")
        row = cur.fetchone()
        nxt = (row[0] or 0) + 1
        conn.close()
        return f"TXN-{datetime.now().year}{nxt:04d}"
    except Exception:
        r = ''.join(random.choices(string.digits, k=6))
        return f"TXN-{r}"


# get unread notif count
def get_unread_count(uid):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM Notification WHERE UserID=? AND IsRead=0", (uid,))
        cnt = cur.fetchone()[0]
        conn.close()
        return cnt
    except Exception:
        return 0


# get wallet balance for user
def get_wallet_balance(uid):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT Balance FROM Wallet WHERE UserID=?", (uid,))
        row = cur.fetchone()
        conn.close()
        return row[0] if row else 0.00
    except Exception:
        return 0.00


# render sidebar with nav buttons
def render_sidebar():
    if 'user_id' not in st.session_state:
        return

    with st.sidebar:
        # user info
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, #1A6B3C, #2E8B57); padding: 20px; 
                    border-radius: 12px; margin-bottom: 20px; color: white; text-align: center;">
            <div style="font-size: 40px; margin-bottom: 8px;">👤</div>
            <div style="font-size: 18px; font-weight: 700;">{st.session_state.get('user_name', 'User')}</div>
            <div style="font-size: 13px; opacity: 0.85; margin-top: 4px;">{st.session_state.get('role', 'User')}</div>
        </div>
        """, unsafe_allow_html=True)

        # show balance
        bal = get_wallet_balance(int(st.session_state.get('user_id', 0)))
        st.markdown(f"""
        <div style="background: #f0faf4; border: 1px solid #1A6B3C; padding: 15px; 
                    border-radius: 10px; margin-bottom: 20px; text-align: center;">
            <div style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 1px;">Balance</div>
            <div style="font-size: 24px; font-weight: 800; color: #1A6B3C;">PKR {bal:,.2f}</div>
        </div>
        """, unsafe_allow_html=True)

        # notif badge
        unread = get_unread_count(int(st.session_state.get('user_id', 0)))
        if unread > 0:
            st.markdown(f"""
            <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 8px 12px; 
                        border-radius: 8px; margin-bottom: 15px; text-align: center;">
                🔔 <strong>{unread}</strong> unread notification{'s' if unread != 1 else ''}
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")

        # nav buttons
        if st.session_state.get('role') == 'Admin':
            if st.button("📊 BI Dashboard", use_container_width=True, key="nav_dashboard"):
                st.switch_page("pages/dashboard.py")

        if st.button("💰 Wallet", use_container_width=True, key="nav_wallet"):
            st.switch_page("pages/wallet.py")
        if st.button("💸 Transfer", use_container_width=True, key="nav_transfer"):
            st.switch_page("pages/transfer.py")
        if st.button("🧾 Bills", use_container_width=True, key="nav_bills"):
            st.switch_page("pages/bills.py")
        if st.button("📜 History", use_container_width=True, key="nav_history"):
            st.switch_page("pages/history.py")
        if st.button(f"🔔 Notifications {'(' + str(unread) + ')' if unread > 0 else ''}", use_container_width=True, key="nav_notif"):
            st.switch_page("pages/notifications.py")
        if st.button("👤 Profile", use_container_width=True, key="nav_profile"):
            st.switch_page("pages/profile.py")

        if st.session_state.get('role') == 'Admin':
            if st.button("⚙️ Admin Panel", use_container_width=True, key="nav_admin"):
                st.switch_page("pages/admin.py")

        st.markdown("---")
        if st.button("🚪 Logout", use_container_width=True, key="nav_logout", type="primary"):
            from utils.auth import logout
            logout()
