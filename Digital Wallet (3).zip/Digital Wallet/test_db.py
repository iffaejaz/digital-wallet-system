# quick test to check db connection and tables
from db import get_connection

conn = get_connection()
cur = conn.cursor()

# get all tables
cur.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME")
tables = [r[0] for r in cur.fetchall()]
print("Tables in DB:", tables)

# get all views
cur.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS ORDER BY TABLE_NAME")
views = [r[0] for r in cur.fetchall()]
print("Views in DB:", views)

# count rows
for t in tables:
    try:
        cur.execute(f"SELECT COUNT(*) FROM [{t}]")
        print(f"  [{t}]: {cur.fetchone()[0]} rows")
    except Exception as e:
        print(f"  [{t}]: ERROR - {e}")

conn.close()
print("\nConnection OK!")
