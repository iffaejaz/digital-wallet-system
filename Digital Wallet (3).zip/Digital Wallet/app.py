# login page

import streamlit as st
from db import get_connection
from utils.auth import hash_password

# page setup
st.set_page_config(
    page_title="Digital Wallet — Login",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# if already logged in go to wallet
if 'user_id' in st.session_state:
    st.switch_page("pages/wallet.py")

# app title
st.title("💳 Digital Wallet")
st.caption("Secure • Fast • Reliable — Your money, your way")
st.divider()

# two columns layout
col_left, col_right = st.columns([1.2, 1], gap="large")

# left side features
with col_left:
    st.subheader("Why Digital Wallet?")

    with st.container(border=True):
        st.info("💸 **Send Money** — Instant peer-to-peer transfers to anyone")

    with st.container(border=True):
        st.info("🧾 **Pay Bills** — Electricity, Gas, Internet & Mobile recharge")

    with st.container(border=True):
        st.info("📊 **Track Spending** — Full transaction history at your fingertips")

    with st.container(border=True):
        st.info("🔒 **Secure** — SHA-256 encrypted passwords keep you safe")

# right side form
with col_right:
    st.subheader("Welcome Back")
    st.caption("Sign in to manage your digital wallet")

    # login form
    with st.form("login_form", clear_on_submit=False):
        email = st.text_input("📧 Email Address", placeholder="you@example.com")
        pwd = st.text_input("🔑 Password", type="password", placeholder="Enter your password")
        submitted = st.form_submit_button("🔓 Sign In", use_container_width=True, type="primary")

    if submitted:
        if not email or not pwd:
            st.error("❌ Please fill in all fields.")
        else:
            with st.spinner("Authenticating..."):
                try:
                    # check db
                    conn = get_connection()
                    cur = conn.cursor()
                    cur.execute(
                        "SELECT UserID, FullName, Role, PasswordHash FROM [User] WHERE Email=? AND IsActive=1",
                        (email,)
                    )
                    user = cur.fetchone()

                    if user and user.PasswordHash == hash_password(pwd):
                        # get wallet id
                        cur.execute(
                            "SELECT WalletID FROM Wallet WHERE UserID=?",
                            (user.UserID,)
                        )
                        wallet = cur.fetchone()
                        conn.close()

                        # save session
                        st.session_state['user_id'] = user.UserID
                        st.session_state['user_name'] = user.FullName
                        st.session_state['role'] = user.Role
                        st.session_state['wallet_id'] = wallet.WalletID if wallet else None

                        st.success(f"✅ Welcome back, {user.FullName}!")
                        st.switch_page("pages/wallet.py")
                    else:
                        conn.close()
                        st.error("❌ Invalid email or password.")
                except Exception as e:
                    st.error(f"❌ Database error: {e}")

    st.divider()

    # register link
    col_a, col_b = st.columns(2)
    with col_a:
        st.write("**Don't have an account?**")
    with col_b:
        if st.button("📝 Create Account", use_container_width=True):
            st.switch_page("pages/register.py")

    st.caption("Demo credentials: **admin@wallet.com** / **password123**")
