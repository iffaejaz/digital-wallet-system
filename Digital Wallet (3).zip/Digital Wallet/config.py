# config for digital wallet app

# db connection string
DB_CONNECTION_STRING = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=DESKTOP-FG9LS3D\\SQLEXPRESS;"
    "DATABASE=DigitalWalletDB;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)

# app settings
APP_NAME = "Digital Wallet"
APP_ICON = "💳"
PRIMARY_COLOR = "#1A6B3C"
CURRENCY = "PKR"
