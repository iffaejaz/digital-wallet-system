# db connection module

import pyodbc
from config import DB_CONNECTION_STRING

# get connection to sql server
def get_connection():
    return pyodbc.connect(DB_CONNECTION_STRING)
