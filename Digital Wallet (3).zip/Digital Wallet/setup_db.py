# setup db script - run once to create tables and insert data
# usage: python setup_db.py

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from db import get_connection

# run a sql command
def run(conn, sql, label=""):
    try:
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit()
        if label:
            print(f"  [OK] {label}")
    except Exception as e:
        err = str(e)
        if "already exists" in err or "already an object" in err or "duplicate" in err.lower():
            if label:
                print(f"  [SKIP] {label} (already exists)")
        else:
            print(f"  [FAIL] {label}: {e}")

# check if table exists
def tbl_exists(conn, name):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME=?", (name,))
    return cur.fetchone()[0] > 0

# check if view exists
def vw_exists(conn, name):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME=?", (name,))
    return cur.fetchone()[0] > 0

# count rows in table
def row_cnt(conn, name):
    cur = conn.cursor()
    cur.execute(f"SELECT COUNT(*) FROM [{name}]")
    return cur.fetchone()[0]

def main():
    conn = get_connection()
    print("=" * 55)
    print("  Digital Wallet -- Database Setup")
    print("=" * 55)
    print()

    # create tables
    print("[1/6] Creating tables...")

    if not tbl_exists(conn, "BillType"):
        run(conn, """
            CREATE TABLE BillType (
                BillTypeID INT PRIMARY KEY IDENTITY(1,1),
                TypeName VARCHAR(50) NOT NULL UNIQUE,
                Description VARCHAR(255) NULL,
                ServiceCharge DECIMAL(6,2) not null DEFAULT 0.00
            )
        """, "BillType")
    else:
        print("  [SKIP] BillType (already exists)")

    if not tbl_exists(conn, "Transaction"):
        run(conn, """
            CREATE TABLE [Transaction] (
                TransactionID INT PRIMARY KEY IDENTITY(1,1),
                SenderWalletID INT not null,
                ReceiverWalletID INT NOT NULL,
                Amount DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
                TransactionDate DATETIME NOT NULL DEFAULT GETDATE(),
                Description VARCHAR(255) NULL,
                Status VARCHAR(20) not null DEFAULT 'Success',
                ReferenceNumber VARCHAR(30) NOT NULL UNIQUE,
                FOREIGN KEY (SenderWalletID) REFERENCES Wallet(WalletID),
                FOREIGN KEY (ReceiverWalletID) REFERENCES Wallet(WalletID)
            )
        """, "Transaction")
    else:
        print("  [SKIP] Transaction (already exists)")

    if not tbl_exists(conn, "BillPayment"):
        run(conn, """
            CREATE TABLE BillPayment (
                BillPaymentID INT PRIMARY KEY IDENTITY(1,1),
                WalletID INT NOT NULL,
                BillTypeID INT not null,
                ConsumerNumber VARCHAR(50) NOT NULL,
                Amount DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
                ServiceCharge DECIMAL(6,2) NOT NULL,
                TotalDeducted DECIMAL(12,2) not null,
                PaymentDate DATETIME NOT NULL DEFAULT GETDATE(),
                Status VARCHAR(20) NOT NULL DEFAULT 'Success',
                FOREIGN KEY (WalletID) REFERENCES Wallet(WalletID),
                FOREIGN KEY (BillTypeID) REFERENCES BillType(BillTypeID)
            )
        """, "BillPayment")
    else:
        print("  [SKIP] BillPayment (already exists)")

    if not tbl_exists(conn, "Notification"):
        run(conn, """
            CREATE TABLE Notification (
                NotificationID INT PRIMARY KEY IDENTITY(1,1),
                UserID INT not null,
                Message VARCHAR(500) NOT NULL,
                Type VARCHAR(30) NOT NULL,
                IsRead BIT NOT NULL DEFAULT 0,
                CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
                FOREIGN KEY (UserID) REFERENCES [User](UserID)
            )
        """, "Notification")
    else:
        print("  [SKIP] Notification (already exists)")

    if not tbl_exists(conn, "TransactionLog"):
        run(conn, """
            CREATE TABLE TransactionLog (
                LogID INT PRIMARY KEY IDENTITY(1,1),
                UserID INT NOT NULL,
                TransactionID INT not null,
                Action VARCHAR(50) NOT NULL,
                LoggedAt DATETIME NOT NULL DEFAULT GETDATE(),
                IPAddress VARCHAR(50) NULL,
                FOREIGN KEY (UserID) REFERENCES [User](UserID),
                FOREIGN KEY (TransactionID) REFERENCES [Transaction](TransactionID)
            )
        """, "TransactionLog")
    else:
        print("  [SKIP] TransactionLog (already exists)")

    # indexes
    print("\n[2/6] Creating indexes...")
    run(conn, "CREATE UNIQUE NONCLUSTERED INDEX idx_user_email ON [User](Email)", "idx_user_email")
    run(conn, "CREATE NONCLUSTERED INDEX idx_wallet_user on Wallet(UserID)", "idx_wallet_user")
    run(conn, "CREATE NONCLUSTERED INDEX idx_txn_sender on [Transaction](SenderWalletID)", "idx_txn_sender")
    run(conn, "CREATE NONCLUSTERED INDEX idx_txn_receiver ON [Transaction](ReceiverWalletID)", "idx_txn_receiver")
    run(conn, "CREATE NONCLUSTERED INDEX idx_txn_date on [Transaction](TransactionDate)", "idx_txn_date")

    # views
    print("\n[3/6] Creating views...")

    if not vw_exists(conn, "vw_WalletSummary"):
        run(conn, """
            CREATE VIEW vw_WalletSummary AS
            select u.UserID, u.FullName, u.Email, w.WalletNumber, w.Balance, w.Status AS WalletStatus
            from [User] u
            JOIN Wallet w ON u.UserID = w.UserID
            where w.Status = 'Active'
        """, "vw_WalletSummary")
    else:
        print("  [SKIP] vw_WalletSummary (already exists)")

    if not vw_exists(conn, "vw_TransactionDetails"):
        run(conn, """
            CREATE VIEW vw_TransactionDetails AS
            select t.TransactionID, t.ReferenceNumber,
                   t.SenderWalletID, t.ReceiverWalletID,
                   u1.FullName AS SenderName, u2.FullName AS ReceiverName,
                   t.Amount, t.TransactionDate, t.Status, t.Description
            FROM [Transaction] t
            join Wallet w1 ON t.SenderWalletID = w1.WalletID
            JOIN Wallet w2 ON t.ReceiverWalletID = w2.WalletID
            join [User] u1 ON w1.UserID = u1.UserID
            JOIN [User] u2 ON w2.UserID = u2.UserID
        """, "vw_TransactionDetails")
    else:
        print("  [SKIP] vw_TransactionDetails (already exists)")

    # alter table
    print("\n[4/6] Schema evolution (ALTER TABLE)...")
    try:
        cur = conn.cursor()
        cur.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='BillType' AND COLUMN_NAME='IsActive'")
        if not cur.fetchone():
            run(conn, "ALTER TABLE BillType ADD IsActive BIT NOT NULL DEFAULT 1", "BillType.IsActive column")
        else:
            print("  [SKIP] BillType.IsActive (already exists)")
    except Exception as e:
        print(f"  [FAIL] ALTER TABLE check: {e}")

    # sample data
    print("\n[5/6] Inserting sample data...")

    # bill types
    if row_cnt(conn, "BillType") == 0:
        run(conn, """
            INSERT INTO BillType (TypeName, Description, ServiceCharge) VALUES
            ('Electricity', 'WAPDA/LESCO bill', 25.00),
            ('Gas',         'SNGPL/SSGC bill', 20.00),
            ('Internet',    'broadband bill', 30.00),
            ('Mobile',      'mobile recharge', 10.00)
        """, "BillType data (4 rows)")
    else:
        print(f"  [SKIP] BillType data ({row_cnt(conn, 'BillType')} rows exist)")

    # transactions
    if row_cnt(conn, "Transaction") == 0:
        run(conn, """
            INSERT INTO [Transaction] (SenderWalletID, ReceiverWalletID, Amount, Description, Status, ReferenceNumber, TransactionDate) VALUES
            (2, 3, 5000.00, 'Rent payment', 'Success', 'TXN-20250001', '2025-01-15 10:30:00'),
            (3, 4, 2000.00, 'Book purchase', 'Success', 'TXN-20250002', '2025-01-18 14:20:00'),
            (5, 2, 8000.00, 'Freelance payment', 'Success', 'TXN-20250003', '2025-01-22 09:15:00'),
            (4, 6, 1500.00, 'Gift', 'Success', 'TXN-20250004', '2025-02-01 11:45:00'),
            (2, 7, 3000.00, 'Tuition fee share', 'Success', 'TXN-20250005', '2025-02-05 16:00:00'),
            (7, 9, 4000.00, 'Monthly contribution', 'Success', 'TXN-20250006', '2025-02-10 08:30:00'),
            (9, 5, 6000.00, 'Loan repayment', 'Success', 'TXN-20250007', '2025-02-14 13:10:00'),
            (6, 8, 500.00, 'Snacks money', 'Success', 'TXN-20250008', '2025-02-18 17:50:00'),
            (8, 10, 200.00, 'Small transfer', 'Success', 'TXN-20250009', '2025-02-22 12:00:00'),
            (10, 2, 100.00, 'Return money', 'Success', 'TXN-20250010', '2025-03-01 10:00:00'),
            (2, 5, 7000.00, 'Project payment', 'Success', 'TXN-20250011', '2025-03-05 15:30:00'),
            (5, 3, 2500.00, 'Shopping split', 'Success', 'TXN-20250012', '2025-03-08 11:20:00'),
            (3, 9, 1000.00, 'Birthday gift', 'Success', 'TXN-20250013', '2025-03-12 14:45:00'),
            (9, 7, 3500.00, 'Commission', 'Success', 'TXN-20250014', '2025-03-15 09:00:00'),
            (7, 4, 2000.00, 'Shared expense', 'Success', 'TXN-20250015', '2025-03-18 16:30:00'),
            (4, 2, 4000.00, 'Salary advance return', 'Success', 'TXN-20250016', '2025-03-22 10:15:00'),
            (2, 8, 1500.00, 'Donation', 'Success', 'TXN-20250017', '2025-03-25 13:40:00'),
            (8, 6, 800.00, 'Food delivery', 'Success', 'TXN-20250018', '2025-03-28 18:00:00'),
            (6, 10, 300.00, 'Transport fare', 'Success', 'TXN-20250019', '2025-04-01 07:30:00'),
            (10, 3, 150.00, 'Small favour', 'Success', 'TXN-20250020', '2025-04-03 12:20:00'),
            (5, 7, 5000.00, 'Partnership share', 'Success', 'TXN-20250021', '2025-04-06 14:00:00'),
            (3, 2, 3000.00, 'Refund', 'Success', 'TXN-20250022', '2025-04-09 11:10:00'),
            (2, 9, 2000.00, 'Monthly payment', 'Success', 'TXN-20250023', '2025-04-12 15:50:00'),
            (7, 5, 1000.00, 'Test transfer', 'Failed', 'TXN-20250024', '2025-04-14 09:30:00'),
            (4, 3, 500.00, 'Quick send', 'Failed', 'TXN-20250025', '2025-04-16 10:00:00')
        """, "Transaction data (25 rows)")
    else:
        print(f"  [SKIP] Transaction data ({row_cnt(conn, 'Transaction')} rows exist)")

    # bill payments
    if row_cnt(conn, "BillPayment") == 0:
        run(conn, """
            INSERT INTO BillPayment (WalletID, BillTypeID, ConsumerNumber, Amount, ServiceCharge, TotalDeducted, PaymentDate, Status) VALUES
            (2, 1, 'ELEC-001234', 3500.00, 25.00, 3525.00, '2025-01-20 10:00:00', 'Success'),
            (3, 1, 'ELEC-005678', 4200.00, 25.00, 4225.00, '2025-02-15 11:30:00', 'Success'),
            (5, 1, 'ELEC-009012', 2800.00, 25.00, 2825.00, '2025-03-10 14:00:00', 'Success'),
            (7, 1, 'ELEC-003456', 5100.00, 25.00, 5125.00, '2025-04-05 09:30:00', 'Success'),
            (2, 2, 'GAS-001111',  1800.00, 20.00, 1820.00, '2025-01-25 13:00:00', 'Success'),
            (4, 2, 'GAS-002222',  2200.00, 20.00, 2220.00, '2025-02-20 15:45:00', 'Success'),
            (9, 2, 'GAS-003333',  1500.00, 20.00, 1520.00, '2025-03-18 10:20:00', 'Success'),
            (3, 3, 'NET-100100',  3000.00, 30.00, 3030.00, '2025-01-30 16:00:00', 'Success'),
            (5, 3, 'NET-200200',  2500.00, 30.00, 2530.00, '2025-02-28 12:30:00', 'Success'),
            (7, 3, 'NET-300300',  4000.00, 30.00, 4030.00, '2025-03-25 08:00:00', 'Success'),
            (6, 3, 'NET-400400',  1800.00, 30.00, 1830.00, '2025-04-10 17:15:00', 'Success'),
            (2, 4, 'MOB-03001234567', 500.00,  10.00, 510.00, '2025-02-05 09:00:00', 'Success'),
            (8, 4, 'MOB-03071234574', 1000.00, 10.00, 1010.00, '2025-03-01 11:00:00', 'Success'),
            (10,4, 'MOB-03091234576', 300.00,  10.00, 310.00, '2025-03-20 14:30:00', 'Success'),
            (4, 4, 'MOB-03031234570', 700.00,  10.00, 710.00, '2025-04-08 16:00:00', 'Success')
        """, "BillPayment data (15 rows)")
    else:
        print(f"  [SKIP] BillPayment data ({row_cnt(conn, 'BillPayment')} rows exist)")

    # notifications
    if row_cnt(conn, "Notification") == 0:
        run(conn, """
            INSERT INTO Notification (UserID, Message, Type, IsRead, CreatedAt) VALUES
            (1,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:00:00'),
            (2,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:05:00'),
            (3,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:10:00'),
            (4,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:15:00'),
            (5,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:20:00'),
            (6,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:25:00'),
            (7,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:30:00'),
            (8,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:35:00'),
            (9,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:40:00'),
            (10, 'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:45:00'),
            (2,  'You sent PKR 5,000 to Sara Ali.', 'Transfer', 1, '2025-01-15 10:30:00'),
            (3,  'You received PKR 5,000 from Ahmed Khan.', 'Transfer', 1, '2025-01-15 10:30:00'),
            (3,  'You sent PKR 2,000 to Usman Tariq.', 'Transfer', 0, '2025-01-18 14:20:00'),
            (4,  'You received PKR 2,000 from Sara Ali.', 'Transfer', 0, '2025-01-18 14:20:00'),
            (5,  'You sent PKR 8,000 to Ahmed Khan.', 'Transfer', 1, '2025-01-22 09:15:00'),
            (2,  'You received PKR 8,000 from Fatima Noor.', 'Transfer', 1, '2025-01-22 09:15:00'),
            (2,  'Electricity bill paid. Amount: PKR 3,525.', 'BillPayment', 1, '2025-01-20 10:00:00'),
            (3,  'Electricity bill paid. Amount: PKR 4,225.', 'BillPayment', 0, '2025-02-15 11:30:00'),
            (5,  'Electricity bill paid. Amount: PKR 2,825.', 'BillPayment', 0, '2025-03-10 14:00:00'),
            (2,  'Gas bill paid. Amount: PKR 1,820.', 'BillPayment', 1, '2025-01-25 13:00:00'),
            (4,  'Gas bill paid. Amount: PKR 2,220.', 'BillPayment', 0, '2025-02-20 15:45:00'),
            (3,  'Internet bill paid. Amount: PKR 3,030.', 'BillPayment', 0, '2025-01-30 16:00:00'),
            (2,  'Mobile top-up successful. Amount: PKR 510.', 'BillPayment', 0, '2025-02-05 09:00:00'),
            (7,  'You sent PKR 4,000 to Zara Sheikh.', 'Transfer', 0, '2025-02-10 08:30:00'),
            (9,  'You received PKR 4,000 from Ayesha Malik.', 'Transfer', 0, '2025-02-10 08:30:00'),
            (9,  'You sent PKR 6,000 to Fatima Noor.', 'Transfer', 0, '2025-02-14 13:10:00'),
            (5,  'You received PKR 6,000 from Zara Sheikh.', 'Transfer', 0, '2025-02-14 13:10:00'),
            (6,  'You sent PKR 500 to Ali Hamza.', 'Transfer', 0, '2025-02-18 17:50:00'),
            (8,  'You received PKR 500 from Hassan Raza.', 'Transfer', 0, '2025-02-18 17:50:00'),
            (2,  'PKR 5,000 added to your wallet.', 'System', 0, '2025-04-15 10:00:00')
        """, "Notification data (30 rows)")
    else:
        print(f"  [SKIP] Notification data ({row_cnt(conn, 'Notification')} rows exist)")

    # txn log
    if row_cnt(conn, "TransactionLog") == 0:
        run(conn, """
            INSERT INTO TransactionLog (UserID, TransactionID, Action, LoggedAt) VALUES
            (2, 1, 'Sent', '2025-01-15 10:30:00'),
            (3, 1, 'Received', '2025-01-15 10:30:00'),
            (3, 2, 'Sent', '2025-01-18 14:20:00'),
            (4, 2, 'Received', '2025-01-18 14:20:00'),
            (5, 3, 'Sent', '2025-01-22 09:15:00'),
            (2, 3, 'Received', '2025-01-22 09:15:00'),
            (4, 4, 'Sent', '2025-02-01 11:45:00'),
            (6, 4, 'Received', '2025-02-01 11:45:00'),
            (2, 5, 'Sent', '2025-02-05 16:00:00'),
            (7, 5, 'Received', '2025-02-05 16:00:00'),
            (7, 6, 'Sent', '2025-02-10 08:30:00'),
            (9, 6, 'Received', '2025-02-10 08:30:00'),
            (9, 7, 'Sent', '2025-02-14 13:10:00'),
            (5, 7, 'Received', '2025-02-14 13:10:00'),
            (6, 8, 'Sent', '2025-02-18 17:50:00'),
            (8, 8, 'Received', '2025-02-18 17:50:00'),
            (8, 9, 'Sent', '2025-02-22 12:00:00'),
            (10,9, 'Received', '2025-02-22 12:00:00'),
            (10,10,'Sent', '2025-03-01 10:00:00'),
            (2, 10,'Received', '2025-03-01 10:00:00'),
            (2, 11,'Sent', '2025-03-05 15:30:00'),
            (5, 11,'Received', '2025-03-05 15:30:00'),
            (5, 12,'Sent', '2025-03-08 11:20:00'),
            (3, 12,'Received', '2025-03-08 11:20:00'),
            (3, 13,'Sent', '2025-03-12 14:45:00')
        """, "TransactionLog data (25 rows)")
    else:
        print(f"  [SKIP] TransactionLog data ({row_cnt(conn, 'TransactionLog')} rows exist)")

    # verify everything
    print("\n[6/6] Verifying all objects...")
    print("-" * 45)

    tables = ["User", "Wallet", "BillType", "Transaction", "BillPayment", "Notification", "TransactionLog"]
    all_ok = True
    for t in tables:
        if tbl_exists(conn, t):
            cnt = row_cnt(conn, t)
            print(f"  [OK] [{t}]: {cnt} rows")
        else:
            print(f"  [FAIL] [{t}]: MISSING!")
            all_ok = False

    views = ["vw_WalletSummary", "vw_TransactionDetails"]
    for v in views:
        if vw_exists(conn, v):
            print(f"  [OK] {v}: exists")
        else:
            print(f"  [FAIL] {v}: MISSING!")
            all_ok = False

    conn.close()

    print("-" * 45)
    if all_ok:
        print("\n>>> DATABASE SETUP COMPLETE! All 7 tables + 2 views ready.")
        print("    Run the app with: streamlit run app.py")
    else:
        print("\n>>> WARNING: Some objects are missing. Check errors above.")

if __name__ == "__main__":
    main()
