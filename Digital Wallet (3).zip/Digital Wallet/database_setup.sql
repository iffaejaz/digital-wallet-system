-- digital wallet management system
-- database setup script
-- db name: DigitalWalletDB

-- use the database
USE DigitalWalletDB;
GO

-- ========================================
-- drop everything first (clean slate)
-- ========================================

-- drop views first
DROP VIEW IF EXISTS vw_total_spent;
DROP VIEW IF EXISTS vw_wallet_balance;
DROP VIEW IF EXISTS vw_user_transactions;
DROP VIEW IF EXISTS vw_TransactionDetails;
DROP VIEW IF EXISTS vw_WalletSummary;
GO

-- drop procedure
DROP PROCEDURE IF EXISTS sp_check_balance;
GO

-- drop tables in correct order
-- child tables first then parent
DROP TABLE IF EXISTS TransactionLog;
DROP TABLE IF EXISTS Notification;
DROP TABLE IF EXISTS BillPayment;
DROP TABLE IF EXISTS [Transaction];
DROP TABLE IF EXISTS BillType;
DROP TABLE IF EXISTS Wallet;
DROP TABLE IF EXISTS [User];
GO

-- ========================================
-- creating tables
-- ========================================

-- user table
CREATE TABLE [User] (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PhoneNumber VARCHAR(15) not null UNIQUE,
    CNIC VARCHAR(15) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) not null,
    Role VARCHAR(20) NOT NULL DEFAULT 'User',
    CreatedAt DATETIME not null DEFAULT GETDATE(),
    IsActive BIT NOT NULL DEFAULT 1
);

-- wallet table - each user has one wallet
CREATE TABLE Wallet (
    WalletID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL UNIQUE,
    WalletNumber VARCHAR(20) not null UNIQUE,
    Balance DECIMAL(12,2) NOT NULL DEFAULT 0.00 CHECK (Balance >= 0),
    Currency VARCHAR(10) NOT NULL DEFAULT 'PKR',
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    Status VARCHAR(20) not null DEFAULT 'Active',
    FOREIGN KEY (UserID) REFERENCES [User](UserID)
);

-- bill types like electricity gas etc
CREATE TABLE BillType (
    BillTypeID INT PRIMARY KEY IDENTITY(1,1),
    TypeName VARCHAR(50) NOT NULL UNIQUE,
    Description VARCHAR(255) NULL,
    ServiceCharge DECIMAL(6,2) not null DEFAULT 0.00
);

-- transaction table for transfers
CREATE TABLE [Transaction] (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    SenderWalletID INT not null,
    ReceiverWalletID INT NOT NULL,
    Amount DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
    TransactionDate DATETIME NOT NULL DEFAULT GETDATE(),
    Description VARCHAR(255) NULL,
    Status VARCHAR(20) not null DEFAULT 'Success',
    ReferenceNumber VARCHAR(30) NOT NULL UNIQUE,
    FOREIGN KEY (SenderWalletID) REFERENCES Wallet(WalletID),
    FOREIGN KEY (ReceiverWalletID) REFERENCES Wallet(WalletID)
);

-- bill payment records
CREATE TABLE BillPayment (
    BillPaymentID INT PRIMARY KEY IDENTITY(1,1),
    WalletID INT NOT NULL,
    BillTypeID INT not null,
    ConsumerNumber VARCHAR(50) NOT NULL,
    Amount DECIMAL(12,2) NOT NULL CHECK (Amount > 0),
    ServiceCharge DECIMAL(6,2) NOT NULL,
    TotalDeducted DECIMAL(12,2) not null,
    PaymentDate DATETIME NOT NULL DEFAULT GETDATE(),
    Status VARCHAR(20) NOT NULL DEFAULT 'Success',
    FOREIGN KEY (WalletID) REFERENCES Wallet(WalletID),
    FOREIGN KEY (BillTypeID) REFERENCES BillType(BillTypeID)
);

-- notifications for users
CREATE TABLE Notification (
    NotificationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT not null,
    Message VARCHAR(500) NOT NULL,
    Type VARCHAR(30) NOT NULL,
    IsRead BIT NOT NULL DEFAULT 0,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES [User](UserID)
);

-- transaction log - keeps record of who did what
CREATE TABLE TransactionLog (
    LogID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    TransactionID INT not null,
    Action VARCHAR(50) NOT NULL,
    LoggedAt DATETIME NOT NULL DEFAULT GETDATE(),
    IPAddress VARCHAR(50) NULL,
    FOREIGN KEY (UserID) REFERENCES [User](UserID),
    FOREIGN KEY (TransactionID) REFERENCES [Transaction](TransactionID)
);

-- ========================================
-- alter table - adding column later
-- ========================================

ALTER TABLE BillType ADD IsActive BIT NOT NULL DEFAULT 1;
GO

-- ========================================
-- indexes to make queries faster
-- ========================================

CREATE UNIQUE NONCLUSTERED INDEX idx_user_email ON [User](Email);
CREATE NONCLUSTERED INDEX idx_wallet_user on Wallet(UserID);
CREATE NONCLUSTERED INDEX idx_txn_sender on [Transaction](SenderWalletID);
CREATE NONCLUSTERED INDEX idx_txn_receiver ON [Transaction](ReceiverWalletID);
CREATE NONCLUSTERED INDEX idx_txn_date on [Transaction](TransactionDate);
GO

-- ========================================
-- views
-- ========================================

-- wallet summary view - join user with wallet
CREATE VIEW vw_WalletSummary AS
select u.UserID, u.FullName, u.Email, w.WalletNumber, w.Balance, w.Status AS WalletStatus
from [User] u
JOIN Wallet w ON u.UserID = w.UserID
where w.Status = 'Active';
GO

-- transaction details view - shows sender and receiver names
CREATE VIEW vw_TransactionDetails AS
select t.TransactionID, t.ReferenceNumber,
       t.SenderWalletID, t.ReceiverWalletID,
       u1.FullName AS SenderName, u2.FullName AS ReceiverName,
       t.Amount, t.TransactionDate, t.Status, t.Description
FROM [Transaction] t
join Wallet w1 ON t.SenderWalletID = w1.WalletID
JOIN Wallet w2 ON t.ReceiverWalletID = w2.WalletID
join [User] u1 ON w1.UserID = u1.UserID
JOIN [User] u2 ON w2.UserID = u2.UserID;
GO

-- ========================================
-- sample data
-- ========================================

-- users (1 admin + 9 normal users)
-- password for all is password123
INSERT INTO [User] (FullName, Email, PhoneNumber, CNIC, PasswordHash, Role, IsActive) VALUES
('Admin User',   'admin@wallet.com', '0300-1234567', '35201-1234567-1', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Admin', 1),
('Ahmed Khan',   'ahmed@gmail.com',  '0301-1234568', '35201-2345678-2', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Sara Ali',     'sara@gmail.com',   '0302-1234569', '35201-3456789-3', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Usman Tariq',  'usman@gmail.com',  '0303-1234570', '35201-4567890-4', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Fatima Noor',  'fatima@gmail.com', '0304-1234571', '35201-5678901-5', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Hassan Raza',  'hassan@gmail.com', '0305-1234572', '35201-6789012-6', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Ayesha Malik', 'ayesha@gmail.com', '0306-1234573', '35201-7890123-7', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Ali Hamza',    'ali@gmail.com',    '0307-1234574', '35201-8901234-8', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Zara Sheikh',  'zara@gmail.com',   '0308-1234575', '35201-9012345-9', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1),
('Bilal Ahmed',  'bilal@gmail.com',  '0309-1234576', '35201-0123456-0', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'User', 1);

-- wallets for each user
INSERT INTO Wallet (UserID, WalletNumber, Balance) VALUES
(1,  'DW-20250001', 50000.00),
(2,  'DW-20250002', 25000.00),
(3,  'DW-20250003', 15000.00),
(4,  'DW-20250004', 8000.00),
(5,  'DW-20250005', 32000.00),
(6,  'DW-20250006', 4500.00),
(7,  'DW-20250007', 18000.00),
(8,  'DW-20250008', 1200.00),
(9,  'DW-20250009', 27000.00),
(10, 'DW-20250010', 600.00);

-- bill types with service charges
INSERT INTO BillType (TypeName, Description, ServiceCharge) VALUES
('Electricity', 'WAPDA/LESCO bill', 25.00),
('Gas',         'SNGPL/SSGC bill', 20.00),
('Internet',    'broadband bill', 30.00),
('Mobile',      'mobile recharge', 10.00);

-- transactions (25 records)
INSERT INTO [Transaction] (SenderWalletID, ReceiverWalletID, Amount, Description, Status, ReferenceNumber, TransactionDate) VALUES
(2, 3, 5000.00, 'Rent payment', 'Success', 'TXN-20250001', '2025-01-15 10:30:00'),
(3, 4, 2000.00, 'Book purchase', 'Success', 'TXN-20250002', '2025-01-18 14:20:00'),
(5, 2, 8000.00, 'Freelance payment', 'Success', 'TXN-20250003', '2025-01-22 09:15:00'),
(4, 6, 1500.00, 'Gift', 'Success', 'TXN-20250004', '2025-02-01 11:45:00'),
(2, 7, 3000.00, 'Tuition fee share', 'Success', 'TXN-20250005', '2025-02-05 16:00:00'),
(7, 9, 4000.00, 'Monthly contribution', 'Success', 'TXN-20250006', '2025-02-10 08:30:00'),
(9, 5, 6000.00, 'Loan repayment', 'Success', 'TXN-20250007', '2025-02-14 13:10:00'),
(6, 8, 500.00, 'Snacks money', 'Success', 'TXN-20250008', '2025-02-18 17:50:00'),
(8, 10, 200.00, 'Small transfer', 'Success', 'TXN-20250009', '2025-02-22 12:00:00'),
(10, 2, 100.00, 'Return money', 'Success', 'TXN-20250010', '2025-03-01 10:00:00'),
(2, 5, 7000.00, 'Project payment', 'Success', 'TXN-20250011', '2025-03-05 15:30:00'),
(5, 3, 2500.00, 'Shopping split', 'Success', 'TXN-20250012', '2025-03-08 11:20:00'),
(3, 9, 1000.00, 'Birthday gift', 'Success', 'TXN-20250013', '2025-03-12 14:45:00'),
(9, 7, 3500.00, 'Commission', 'Success', 'TXN-20250014', '2025-03-15 09:00:00'),
(7, 4, 2000.00, 'Shared expense', 'Success', 'TXN-20250015', '2025-03-18 16:30:00'),
(4, 2, 4000.00, 'Salary advance return', 'Success', 'TXN-20250016', '2025-03-22 10:15:00'),
(2, 8, 1500.00, 'Donation', 'Success', 'TXN-20250017', '2025-03-25 13:40:00'),
(8, 6, 800.00, 'Food delivery', 'Success', 'TXN-20250018', '2025-03-28 18:00:00'),
(6, 10, 300.00, 'Transport fare', 'Success', 'TXN-20250019', '2025-04-01 07:30:00'),
(10, 3, 150.00, 'Small favour', 'Success', 'TXN-20250020', '2025-04-03 12:20:00'),
(5, 7, 5000.00, 'Partnership share', 'Success', 'TXN-20250021', '2025-04-06 14:00:00'),
(3, 2, 3000.00, 'Refund', 'Success', 'TXN-20250022', '2025-04-09 11:10:00'),
(2, 9, 2000.00, 'Monthly payment', 'Success', 'TXN-20250023', '2025-04-12 15:50:00'),
(7, 5, 1000.00, 'Test transfer', 'Failed', 'TXN-20250024', '2025-04-14 09:30:00'),
(4, 3, 500.00, 'Quick send', 'Failed', 'TXN-20250025', '2025-04-16 10:00:00');

-- bill payments (15 records)
INSERT INTO BillPayment (WalletID, BillTypeID, ConsumerNumber, Amount, ServiceCharge, TotalDeducted, PaymentDate, Status) VALUES
(2, 1, 'ELEC-001234', 3500.00, 25.00, 3525.00, '2025-01-20 10:00:00', 'Success'),
(3, 1, 'ELEC-005678', 4200.00, 25.00, 4225.00, '2025-02-15 11:30:00', 'Success'),
(5, 1, 'ELEC-009012', 2800.00, 25.00, 2825.00, '2025-03-10 14:00:00', 'Success'),
(7, 1, 'ELEC-003456', 5100.00, 25.00, 5125.00, '2025-04-05 09:30:00', 'Success'),
(2, 2, 'GAS-001111',  1800.00, 20.00, 1820.00, '2025-01-25 13:00:00', 'Success'),
(4, 2, 'GAS-002222',  2200.00, 20.00, 2220.00, '2025-02-20 15:45:00', 'Success'),
(9, 2, 'GAS-003333',  1500.00, 20.00, 1520.00, '2025-03-18 10:20:00', 'Success'),
(3, 3, 'NET-100100',  3000.00, 30.00, 3030.00, '2025-01-30 16:00:00', 'Success'),
(5, 3, 'NET-200200',  2500.00, 30.00, 2530.00, '2025-02-28 12:30:00', 'Success'),
(7, 3, 'NET-300300',  4000.00, 30.00, 4030.00, '2025-03-25 08:00:00', 'Success'),
(6, 3, 'NET-400400',  1800.00, 30.00, 1830.00, '2025-04-10 17:15:00', 'Success'),
(2, 4, 'MOB-03001234567', 500.00,  10.00, 510.00, '2025-02-05 09:00:00', 'Success'),
(8, 4, 'MOB-03071234574', 1000.00, 10.00, 1010.00, '2025-03-01 11:00:00', 'Success'),
(10,4, 'MOB-03091234576', 300.00,  10.00, 310.00, '2025-03-20 14:30:00', 'Success'),
(4, 4, 'MOB-03031234570', 700.00,  10.00, 710.00, '2025-04-08 16:00:00', 'Success');

-- notifications (30 records)
INSERT INTO Notification (UserID, Message, Type, IsRead, CreatedAt) VALUES
(1,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:00:00'),
(2,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:05:00'),
(3,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:10:00'),
(4,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:15:00'),
(5,  'Welcome to Digital Wallet!', 'System', 1, '2025-01-01 08:20:00'),
(6,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:25:00'),
(7,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:30:00'),
(8,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:35:00'),
(9,  'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:40:00'),
(10, 'Welcome to Digital Wallet!', 'System', 0, '2025-01-01 08:45:00'),
(2,  'You sent PKR 5,000 to Sara Ali.', 'Transfer', 1, '2025-01-15 10:30:00'),
(3,  'You received PKR 5,000 from Ahmed Khan.', 'Transfer', 1, '2025-01-15 10:30:00'),
(3,  'You sent PKR 2,000 to Usman Tariq.', 'Transfer', 0, '2025-01-18 14:20:00'),
(4,  'You received PKR 2,000 from Sara Ali.', 'Transfer', 0, '2025-01-18 14:20:00'),
(5,  'You sent PKR 8,000 to Ahmed Khan.', 'Transfer', 1, '2025-01-22 09:15:00'),
(2,  'You received PKR 8,000 from Fatima Noor.', 'Transfer', 1, '2025-01-22 09:15:00'),
(2,  'Electricity bill paid. Amount: PKR 3,525.', 'BillPayment', 1, '2025-01-20 10:00:00'),
(3,  'Electricity bill paid. Amount: PKR 4,225.', 'BillPayment', 0, '2025-02-15 11:30:00'),
(5,  'Electricity bill paid. Amount: PKR 2,825.', 'BillPayment', 0, '2025-03-10 14:00:00'),
(2,  'Gas bill paid. Amount: PKR 1,820.', 'BillPayment', 1, '2025-01-25 13:00:00'),
(4,  'Gas bill paid. Amount: PKR 2,220.', 'BillPayment', 0, '2025-02-20 15:45:00'),
(3,  'Internet bill paid. Amount: PKR 3,030.', 'BillPayment', 0, '2025-01-30 16:00:00'),
(2,  'Mobile top-up successful. Amount: PKR 510.', 'BillPayment', 0, '2025-02-05 09:00:00'),
(7,  'You sent PKR 4,000 to Zara Sheikh.', 'Transfer', 0, '2025-02-10 08:30:00'),
(9,  'You received PKR 4,000 from Ayesha Malik.', 'Transfer', 0, '2025-02-10 08:30:00'),
(9,  'You sent PKR 6,000 to Fatima Noor.', 'Transfer', 0, '2025-02-14 13:10:00'),
(5,  'You received PKR 6,000 from Zara Sheikh.', 'Transfer', 0, '2025-02-14 13:10:00'),
(6,  'You sent PKR 500 to Ali Hamza.', 'Transfer', 0, '2025-02-18 17:50:00'),
(8,  'You received PKR 500 from Hassan Raza.', 'Transfer', 0, '2025-02-18 17:50:00'),
(2,  'PKR 5,000 added to your wallet.', 'System', 0, '2025-04-15 10:00:00');

-- transaction log entries
INSERT INTO TransactionLog (UserID, TransactionID, Action, LoggedAt) VALUES
(2, 1, 'Sent', '2025-01-15 10:30:00'),
(3, 1, 'Received', '2025-01-15 10:30:00'),
(3, 2, 'Sent', '2025-01-18 14:20:00'),
(4, 2, 'Received', '2025-01-18 14:20:00'),
(5, 3, 'Sent', '2025-01-22 09:15:00'),
(2, 3, 'Received', '2025-01-22 09:15:00'),
(4, 4, 'Sent', '2025-02-01 11:45:00'),
(6, 4, 'Received', '2025-02-01 11:45:00'),
(2, 5, 'Sent', '2025-02-05 16:00:00'),
(7, 5, 'Received', '2025-02-05 16:00:00'),
(7, 6, 'Sent', '2025-02-10 08:30:00'),
(9, 6, 'Received', '2025-02-10 08:30:00'),
(9, 7, 'Sent', '2025-02-14 13:10:00'),
(5, 7, 'Received', '2025-02-14 13:10:00'),
(6, 8, 'Sent', '2025-02-18 17:50:00'),
(8, 8, 'Received', '2025-02-18 17:50:00'),
(8, 9, 'Sent', '2025-02-22 12:00:00'),
(10,9, 'Received', '2025-02-22 12:00:00'),
(10,10,'Sent', '2025-03-01 10:00:00'),
(2, 10,'Received', '2025-03-01 10:00:00'),
(2, 11,'Sent', '2025-03-05 15:30:00'),
(5, 11,'Received', '2025-03-05 15:30:00'),
(5, 12,'Sent', '2025-03-08 11:20:00'),
(3, 12,'Received', '2025-03-08 11:20:00'),
(3, 13,'Sent', '2025-03-12 14:45:00');


-- ========================================
-- TASK 2: additional parts
-- ========================================

-- index on status column to speed up status filter
create index idx_tran_status
on [Transaction](Status)
GO

-- two types of views:
-- 1) virtual view - runs when you call it
--    always shows latest data but bit slow
--    used in normal databases
-- 2) materialized view - data already saved
--    faster but data might be old
--    used in data warehouses

GO
-- virtual view - user transactions through wallet join
create view vw_user_transactions as
select u.FullName, t.Amount, t.TransactionDate
from [User] u
join Wallet w on u.UserID = w.UserID
join [Transaction] t on w.WalletID = t.SenderWalletID
GO

-- virtual view - wallet balance per user
create view vw_wallet_balance as
select u.FullName, w.Balance
from [User] u
join Wallet w on u.UserID = w.UserID
GO

-- materialized view with schemabinding
-- joins through Wallet since Transaction has no UserID
create view vw_total_spent
with schemabinding as
select w.UserID, u.FullName,
count_big(*) as total_txns,
sum(t.Amount) as total_spent
from dbo.[User] u
join dbo.Wallet w on u.UserID = w.UserID
join dbo.[Transaction] t
on w.WalletID = t.SenderWalletID
group by w.UserID, u.FullName
GO

create unique clustered index
idx_total_spent on vw_total_spent(UserID)
GO

-- ========================================
-- T-SQL stuff
-- ========================================

-- variables
declare @uid int
declare @bal decimal(10,2)
set @uid = 1
set @bal = 5000.00
select @uid as id, @bal as balance
GO

-- if else check
declare @balance decimal(10,2)
set @balance = 1500.00
if @balance > 1000
    print 'balance is fine'
else if @balance > 500
    print 'balance getting low'
else
    print 'not enough balance'
GO

-- while loop
declare @i int = 1
while @i <= 5
begin
    print 'record ' + cast(@i as varchar)
    set @i = @i + 1
end
GO

-- simple stored procedure
create procedure sp_check_balance
    @uid int
as
begin
    if exists(select 1 from [User]
              where UserID = @uid)
    begin
        select u.FullName, w.Balance
        from [User] u
        join Wallet w on u.UserID = w.UserID
        where u.UserID = @uid
        print 'done'
    end
    else
        print 'user not found'
end
GO

exec sp_check_balance @uid = 1
GO

-- try catch
begin try
    update Wallet
    set Balance = Balance - 500
    where UserID = 1
    print 'transfer done'
end try
begin catch
    print 'error: ' + error_message()
end catch
GO
